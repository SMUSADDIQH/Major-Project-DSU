export class User {
  id: number | undefined;
  loginUserId: string | undefined;
  userType: string | undefined;
  userId: string | undefined;
  authdata?: string;
}

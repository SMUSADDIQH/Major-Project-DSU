export interface Response {
  status: string;
}

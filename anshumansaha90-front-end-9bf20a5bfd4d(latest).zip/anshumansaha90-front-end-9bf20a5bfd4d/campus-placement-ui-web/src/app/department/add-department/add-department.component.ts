import { Component, Inject } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-add-department',
  templateUrl: './add-department.component.html',
  styleUrls: ['./add-department.component.css']
})
export class AddDepartmentComponent {
  isEdit: boolean = false;
  departmentId: number = 0;
  departmentRegistrationForm = this.fb.group({
    departmentName: ['', Validators.required],
    departmentCode: ['', Validators.required]
  });
  constructor(
    private activatedRoute: ActivatedRoute,
    private departmentService: DepartmentService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AddDepartmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DepartmentEditModel
    ) {
      if(data) {
        this.isEdit = true;
        this.departmentRegistrationForm.setValue({departmentName: data.departmentName, departmentCode: data.departmentCode});
        this.departmentId = data.departmentId;
      }
     }

  onSubmit() {
    const departmentName = this.departmentRegistrationForm.value.departmentName;
    const departmentCode = this.departmentRegistrationForm.value.departmentCode;
    const departmentId = this.departmentId;

    if(this.isEdit) {
      this.departmentService.updateDepartment(departmentName, departmentCode, departmentId).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
    else {
    this.departmentService.addDepartment(departmentName, departmentCode).subscribe({
      next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
    });
  }
  }

  callbackResponse(response: any) {
    if (response && response['status'] === 'success') {
      this.toastr.success('inserted or updated successfully', 'Success');
    }
  }

  callbackError(err: any) {
    console.error(err);
    this.toastr.error('Failed to insert or update', 'Failure');
  }
}

export class DepartmentEditModel {
  constructor(
    public departmentName: string,
    public departmentCode: string,
    public departmentId: number
  ){
  }
}

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { AddDepartmentComponent, DepartmentEditModel } from '../add-department/add-department.component';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-view-department',
  templateUrl: './view-department.component.html',
  styleUrls: ['./view-department.component.css']
})
export class ViewDepartmentComponent implements OnInit {
  displayedColumns: string[] = ['departmentId', 'departmentName', 'departmentCode','sts','actions'];
  dataSource!: Departments[];

  constructor(
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private departmentService: DepartmentService,
    private toastr: ToastrService
    ) { }
  ngOnInit(): void {
    console.log('ViewDepartmentComponent');
    this.activatedRoute.data.subscribe((response: any) => {
      this.dataSource = response.departments;
    });
  }

  onEdit(element: any) {
    const message = 'Are you sure you want to edit' + element.departmentName + '?';
    const dialogData = new DepartmentEditModel(element.departmentName, element.departmentCode, element.departmentId);
    const dialogRef = this.dialog.open(AddDepartmentComponent, {
      maxWidth: "400px",
      data: dialogData
    });
  }

  onDelete(element: any) {
    const message = 'Are you sure you want to delete Department: ' + element.departmentName + '?';

    const dialogData = new ConfirmDialogModel("Confirm Action", message, false);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        const department_id = element.departmentId;
        this.departmentService.deleteDepartment(department_id).subscribe({
          next: (result) => {
            if (result.status === 'success') {
              this.toastr.success('Sucessfully deleted!', 'Success');
              this.refresh();
            }
          }
        })
      }
    });
  }

  refresh() {
    this.departmentService.getDepartmentDetails().subscribe({
      next: (response) => {
        if (response) {
          this.dataSource = response;
        }
      }
    })
  }
}

export interface Departments {
  departmentId: number;
  departmentName: number;
  departmentCode: number;
  departmentStatus: string;
  sts: string;
}

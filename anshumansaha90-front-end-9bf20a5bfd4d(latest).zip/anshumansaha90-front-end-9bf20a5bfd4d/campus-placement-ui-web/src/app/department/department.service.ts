import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { Response } from '../model/response';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  constructor(private httpService: HttpServiceService) { }

  getDepartmentDetails(): Observable<any> {
    return this.httpService.get(null, 'listDepartment');
  }

  deleteDepartment(department_id: string): Observable<Response> {
    return this.httpService.delete(department_id, 'deleteDepartment');
  }

  addDepartment(departmentName: string, departmentCode: string) {
    const body = {
      departments: {
        departmentName: departmentName,
        departmentCode: departmentCode
      }
    };
    return this.httpService.post(body, 'insertDepartment');
  }

  updateDepartment(departmentName: string, departmentCode: string, departmentId: number) {
    const body = {
      departments: {
        departmentName: departmentName,
        departmentCode: departmentCode,
        departmentId: departmentId
      }
    };
    return this.httpService.post(body, 'updateDepartment');
  }
}

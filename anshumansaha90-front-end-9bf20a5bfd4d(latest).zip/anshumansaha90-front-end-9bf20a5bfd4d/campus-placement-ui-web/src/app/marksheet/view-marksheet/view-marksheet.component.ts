import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-marksheet',
  templateUrl: './view-marksheet.component.html',
  styleUrls: ['./view-marksheet.component.css']
})
export class ViewMarksheetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

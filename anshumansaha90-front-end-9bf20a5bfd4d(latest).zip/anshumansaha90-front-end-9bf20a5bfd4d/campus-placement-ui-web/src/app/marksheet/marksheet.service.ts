import { Injectable } from '@angular/core';
import { HttpServiceService } from '../core/http-service.service';

@Injectable({
  providedIn: 'root'
})
export class MarksheetService {

  constructor(private httpService: HttpServiceService) { }

  insertOrUpdateMarksheet(marksheetData: any) {
    const body = {
      marksheet: marksheetData
    };
    return this.httpService.post(body, 'insertMarksheet');
  }
}

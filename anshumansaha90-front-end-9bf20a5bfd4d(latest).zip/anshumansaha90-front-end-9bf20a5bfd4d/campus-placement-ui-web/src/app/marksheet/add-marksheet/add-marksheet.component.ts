import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { Students } from 'src/app/student/view-student/view-student.component';
import { MarksheetService } from '../marksheet.service';

@Component({
  selector: 'app-add-marksheet',
  templateUrl: './add-marksheet.component.html',
  styleUrls: ['./add-marksheet.component.css']
})
export class AddMarksheetComponent implements OnInit {
  studentData!: Students;
  marksheetAdditionForm = this.fb.group({
    studentName: ['', Validators.required],
    departmentName: ['', Validators.required],
    semister1: ['', Validators.required],
    semister2: ['', Validators.required],
    semister3: ['', Validators.required],
    semister4: ['', Validators.required],
    semister5: ['', Validators.required],
    semister6: ['', Validators.required],
    semister7: ['', Validators.required],
    semister8: ['', Validators.required],
  });
  constructor(
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private authenticationService: AuthenticationService,
    private marksheetService: MarksheetService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      this.studentData = response.student;
      this.setFormValue();
    })
  }

  onSubmit() {
    const user = this.authenticationService.userValue;
    const obj = {
      studentId :  user.userId,
      loginUserId: user.loginUserId,
      semister1: this.marksheetAdditionForm.value.semister1,
      semister2: this.marksheetAdditionForm.value.semister2,
      semister3: this.marksheetAdditionForm.value.semister3,
      semister4: this.marksheetAdditionForm.value.semister4,
      semister5: this.marksheetAdditionForm.value.semister5,
      semister6: this.marksheetAdditionForm.value.semister6,
      semister7: this.marksheetAdditionForm.value.semister7,
      semister8: this.marksheetAdditionForm.value.semister8,
    };
    this.marksheetService.insertOrUpdateMarksheet(obj).subscribe({
      next: (response) => {
        if(response && response['status'] === 'success') {
          this.toastr.success('inserted or updated successfully', 'Success');
        }
        else {
            this.toastr.error('Failed to insert or update','Failure')
        }
      },
      error: (err) => {
        this.toastr.error('Server Failure!!!', 'Failure');
      }
    })
  }

  setFormValue() {
    this.marksheetAdditionForm.setValue(
      {
        studentName: this.studentData.studentName,
        departmentName: this.studentData.departmentName,
        semister1: (!this.studentData.semister1) ? 0 : this.studentData.semister1,
        semister2: (!this.studentData.semister2) ? 0 : this.studentData.semister2,
        semister3: (!this.studentData.semister3) ? 0 : this.studentData.semister3,
        semister4: (!this.studentData.semister4) ? 0 : this.studentData.semister4,
        semister5: (!this.studentData.semister5) ? 0 : this.studentData.semister5,
        semister6: (!this.studentData.semister6) ? 0 : this.studentData.semister6,
        semister7: (!this.studentData.semister7) ? 0 : this.studentData.semister7,
        semister8: (!this.studentData.semister8) ? 0 : this.studentData.semister8,
      }
    )
  }
}

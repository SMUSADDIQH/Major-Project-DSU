import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { JobsService } from "src/app/jobs/jobs.service";
import { StudentService } from "src/app/student/student.service";

export class StudentResolver {
}

@Injectable({ providedIn: 'root' })
export class viewStudentDetailResolver implements Resolve<any> {
  constructor(private studentService: StudentService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.studentService.getStudentDetailById();
  }
}

@Injectable({ providedIn: 'root' })
export class viewNonApplicableJobsResolver implements Resolve<any> {
  constructor(private jobService: JobsService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.jobService.getNonApplicableJobs();
  }
}

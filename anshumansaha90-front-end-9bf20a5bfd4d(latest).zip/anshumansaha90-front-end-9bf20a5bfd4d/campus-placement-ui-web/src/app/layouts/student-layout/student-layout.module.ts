import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ApplicableComponent } from 'src/app/jobs/applicable/applicable.component';
import { NonApplicableComponent } from 'src/app/jobs/non-applicable/non-applicable.component';
import { AddMarksheetComponent } from 'src/app/marksheet/add-marksheet/add-marksheet.component';
import { MarksheetComponent } from 'src/app/marksheet/marksheet.component';
import { ViewMarksheetComponent } from 'src/app/marksheet/view-marksheet/view-marksheet.component';
import { MatModule } from 'src/app/module/mat/mat.module';
import { StudentLayoutRoutingModule } from './student-layout-routing.module';


@NgModule({
  declarations: [
    MarksheetComponent,
    AddMarksheetComponent,
    ViewMarksheetComponent,
    ApplicableComponent,
    NonApplicableComponent
  ],
  imports: [
    CommonModule,
    StudentLayoutRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatModule
  ]
})
export class StudentLayoutModule { }

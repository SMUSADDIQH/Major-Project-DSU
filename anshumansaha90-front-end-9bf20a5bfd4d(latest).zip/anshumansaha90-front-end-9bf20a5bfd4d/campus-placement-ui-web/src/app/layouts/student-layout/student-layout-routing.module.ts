import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { ApplicableComponent } from 'src/app/jobs/applicable/applicable.component';
import { JobsComponent } from 'src/app/jobs/jobs.component';
import { NonApplicableComponent } from 'src/app/jobs/non-applicable/non-applicable.component';
import { AddMarksheetComponent } from 'src/app/marksheet/add-marksheet/add-marksheet.component';
import { MarksheetComponent } from 'src/app/marksheet/marksheet.component';
import { viewNonApplicableJobsResolver, viewStudentDetailResolver } from './student-resolver';

export const studentLayoutRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  {
    path: '',
    redirectTo: 'marksheet',
    pathMatch: 'full'
  },
  {
    path: 'marksheet',
    component: MarksheetComponent,
    children: [
      {
        path: '',
        redirectTo: 'add',
        pathMatch: 'full'
      },
      {
        path: 'add',
        component: AddMarksheetComponent,
        resolve: {
          student: viewStudentDetailResolver
        }
      }
    ]
  },
  {
    path: 'jobs',
    component: JobsComponent,
    data: {
      'module': 'student'
    },
    children: [
      {
        path: '',
        redirectTo: 'applicable',
        pathMatch: 'full'
      },
      {
        path: 'applicable',
        component: ApplicableComponent,
        resolve: {
          student: viewStudentDetailResolver
        }
      },
      {
        path: 'non-applicable',
        component: NonApplicableComponent,
        resolve: {
          nonApplicableJobs: viewNonApplicableJobsResolver
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(studentLayoutRoutes)],
  exports: [RouterModule]
})
export class StudentLayoutRoutingModule { }

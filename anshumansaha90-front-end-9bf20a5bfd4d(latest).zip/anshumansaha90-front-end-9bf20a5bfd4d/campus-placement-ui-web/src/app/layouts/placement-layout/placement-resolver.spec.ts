import { PlacementResolver } from './placement-resolver';

describe('PlacementResolver', () => {
  it('should create an instance', () => {
    expect(new PlacementResolver()).toBeTruthy();
  });
});

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PostJobsComponent } from 'src/app/jobs/post-jobs/post-jobs.component';
import { ViewJobsComponent } from 'src/app/jobs/view-jobs/view-jobs.component';
import { MatModule } from 'src/app/module/mat/mat.module';
import { PlacementLayoutRoutingModule } from './placement-layout-routing.module';


@NgModule({
  declarations: [
    ViewJobsComponent,
    PostJobsComponent
  ],
  imports: [
    CommonModule,
    PlacementLayoutRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatModule
  ],
  providers: [

  ]
})
export class PlacementLayoutModule { }

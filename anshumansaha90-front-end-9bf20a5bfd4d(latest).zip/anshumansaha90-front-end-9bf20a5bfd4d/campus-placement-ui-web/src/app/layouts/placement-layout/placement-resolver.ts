import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { JobsService } from "src/app/jobs/jobs.service";

export class PlacementResolver {
}

@Injectable({ providedIn: 'root' })
export class viewJobDetailResolver implements Resolve<any> {
  constructor(private jobService: JobsService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.jobService.getJobDetails();
  }
}

import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { JobsComponent } from 'src/app/jobs/jobs.component';
import { PostJobsComponent } from 'src/app/jobs/post-jobs/post-jobs.component';
import { ViewJobsComponent } from 'src/app/jobs/view-jobs/view-jobs.component';
import { viewDepartmentResolver } from '../admin-layout/admin-resolver';
import { viewJobDetailResolver } from './placement-resolver';

const routes: Routes = [{ path: 'dashboard', component: DashboardComponent },
{
  path: '',
  redirectTo: 'jobs',
  pathMatch: 'full'
},
{
  path: 'jobs',
  component: JobsComponent,
  data: {
    'module': 'placement'
  },
  children: [
    {
      path: '',
      redirectTo: 'view',
      pathMatch: 'full'
    },
    {
      path: 'view',
      component: ViewJobsComponent,
      resolve: {
        jobDetails: viewJobDetailResolver
      }
    },
    {
      path: 'post',
      component: PostJobsComponent,
      resolve : {
        departments: viewDepartmentResolver
      }
    }
  ]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PlacementLayoutRoutingModule { }

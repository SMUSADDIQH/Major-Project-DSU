import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { HodService } from "src/app/hod/hod.service";

export class HodResolver {
}

@Injectable({ providedIn: 'root' })
export class viewStudentByhodResolver implements Resolve<any> {
  constructor(private hodService: HodService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.hodService.getStudentDetailsByHodId();
  }
}

@Injectable({ providedIn: 'root' })
export class viewHodDetailsByhodIdResolver implements Resolve<any> {
  constructor(private hodService: HodService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.hodService.getHodDetailsByHodId();
  }
}

@Injectable({ providedIn: 'root' })
export class viewJobDetailsByDepartmentIdResolver implements Resolve<any> {
  constructor(private hodService: HodService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.hodService.getJobprofileByDepartmentId();
  }
}

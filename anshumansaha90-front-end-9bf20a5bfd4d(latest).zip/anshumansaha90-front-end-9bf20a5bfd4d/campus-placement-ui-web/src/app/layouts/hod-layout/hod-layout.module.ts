import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatModule } from 'src/app/module/mat/mat.module';
import { AddStudentComponent } from 'src/app/student/add-student/add-student.component';
import { HodLayoutRoutingModule } from './hod-layout-routing.module';


@NgModule({
  declarations: [

  ],
  imports: [
    CommonModule,
    HodLayoutRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MatModule
  ],
  providers: [
    {
      provide: MatDialogRef,
      useValue: null
    },
    {
      provide: MAT_DIALOG_DATA,
      useValue: null
    },
    AddStudentComponent,
  ]
})
export class HodLayoutModule { }

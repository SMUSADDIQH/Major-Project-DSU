import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { JobsComponent } from 'src/app/jobs/jobs.component';
import { ViewJobsComponent } from 'src/app/jobs/view-jobs/view-jobs.component';
import { AddStudentComponent } from 'src/app/student/add-student/add-student.component';
import { StudentComponent } from 'src/app/student/student.component';
import { ViewStudentComponent } from 'src/app/student/view-student/view-student.component';
import { viewDepartmentResolver } from '../admin-layout/admin-resolver';
import { viewJobDetailsByDepartmentIdResolver, viewStudentByhodResolver } from './hod-resolver';

export const hodLayoutRoutes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  {
    path: '',
    redirectTo: 'students',
    pathMatch: 'full'
  },
  {
    path: 'students',
    component: StudentComponent,
    children: [
      {
        path: '',
        redirectTo: 'view',
        pathMatch: 'full'
      },
      {
        path: 'view',
        component: ViewStudentComponent,
        resolve: {
          students: viewStudentByhodResolver
        }
      },
      {
        path: 'add',
        component: AddStudentComponent,
        resolve: {
          departments: viewDepartmentResolver
        }
      }
    ]
  },
  {
    path: 'jobs',
    component: JobsComponent,
    data: {
      'module': 'hod'
    },
    children: [
      {
        path: '',
        redirectTo: 'view',
        pathMatch: 'full'
      },
      {
        path: 'view',
        component: ViewJobsComponent,
        resolve: {
          jobDetails: viewJobDetailsByDepartmentIdResolver
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(hodLayoutRoutes)],
  exports: [RouterModule]
})
export class HodLayoutRoutingModule { }

import { Routes } from '@angular/router';
import { AddDepartmentComponent } from 'src/app/department/add-department/add-department.component';
import { DepartmentComponent } from 'src/app/department/department.component';
import { ViewDepartmentComponent } from 'src/app/department/view-department/view-department.component';

import { AddHodComponent } from 'src/app/hod/add-hod/add-hod.component';
import { HodComponent } from 'src/app/hod/hod.component';
import { ViewHodComponent } from 'src/app/hod/view-hod/view-hod.component';
import { AddPlacementOfficerComponent } from 'src/app/placement-officer/add-placement-officer/add-placement-officer.component';
import { PlacementOfficerComponent } from 'src/app/placement-officer/placement-officer.component';
import { ViewPlacementOfficerComponent } from 'src/app/placement-officer/view-placement-officer/view-placement-officer.component';
import { AddStudentComponent } from 'src/app/student/add-student/add-student.component';
import { StudentComponent } from 'src/app/student/student.component';
import { ViewStudentComponent } from 'src/app/student/view-student/view-student.component';
import { DashboardComponent } from '../../dashboard/dashboard.component';
import { viewDepartmentResolver, viewHodResolver, viewPlacementResolver, viewStudentResolver } from './admin-resolver';

export const AdminLayoutRoutes: Routes = [
    { path: 'dashboard',      component: DashboardComponent },
    {
      path: '',
      redirectTo: 'students',
      pathMatch: 'full'
    },
    {
      path: 'students',
      component: StudentComponent,
      children: [
        {
          path: '',
          redirectTo: 'view',
          pathMatch: 'full'
        },
        {
          path: 'view',
          component: ViewStudentComponent,
          resolve: {
            students: viewStudentResolver
          }
        },
        {
          path: 'add',
          component: AddStudentComponent,
          resolve: {
            departments: viewDepartmentResolver
          }
        }
      ]
    },
    {
      path: 'hod',
      component: HodComponent,
      children: [
        {
          path: '',
          redirectTo: 'view',
          pathMatch: 'full'
        },
        {
          path: 'view',
          component: ViewHodComponent,
          resolve: {
            hod: viewHodResolver
          }
        },
        {
          path: 'add',
          component: AddHodComponent,
          resolve: {
            departments: viewDepartmentResolver
          }
        }
      ]
    },
    {
      path: 'department',
      component: DepartmentComponent,
      children: [
        {
          path: '',
          redirectTo: 'view',
          pathMatch: 'full'
        },
        {
          path: 'view',
          component: ViewDepartmentComponent,
          resolve: {
            departments: viewDepartmentResolver
          }
        },
        {
          path: 'add',
          component: AddDepartmentComponent
        }
      ]
    },
    {
      path: 'placement',
      component: PlacementOfficerComponent,
      children: [
        {
          path: '',
          redirectTo: 'view',
          pathMatch: 'full'
        },
        {
          path: 'view',
          component: ViewPlacementOfficerComponent,
          resolve: {
            placement: viewPlacementResolver
          }
        },
        {
          path: 'add',
          component: AddPlacementOfficerComponent
        }
      ]
    }
];

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterModule } from '@angular/router';
import { AddDepartmentComponent } from 'src/app/department/add-department/add-department.component';
import { DepartmentComponent } from 'src/app/department/department.component';
import { ViewDepartmentComponent } from 'src/app/department/view-department/view-department.component';
import { AddHodComponent } from 'src/app/hod/add-hod/add-hod.component';
import { HodComponent } from 'src/app/hod/hod.component';
import { ViewHodComponent } from 'src/app/hod/view-hod/view-hod.component';
import { AddPlacementOfficerComponent } from 'src/app/placement-officer/add-placement-officer/add-placement-officer.component';
import { PlacementOfficerComponent } from 'src/app/placement-officer/placement-officer.component';
import { ViewPlacementOfficerComponent } from 'src/app/placement-officer/view-placement-officer/view-placement-officer.component';
import { AddStudentComponent } from 'src/app/student/add-student/add-student.component';
import { StudentComponent } from 'src/app/student/student.component';
import { ViewStudentComponent } from 'src/app/student/view-student/view-student.component';
import { MatModule } from '../../module/mat/mat.module';
import { AdminLayoutRoutes } from './admin-layout.routing';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    MatModule
  ],
  declarations: [
    StudentComponent,
    AddStudentComponent,
    ViewStudentComponent,
    HodComponent,
    AddHodComponent,
    ViewHodComponent,
    PlacementOfficerComponent,
    ViewPlacementOfficerComponent,
    AddPlacementOfficerComponent,
    DepartmentComponent,
    AddDepartmentComponent,
    ViewDepartmentComponent
  ],
  providers: [
    {
      provide: MatDialogRef,
      useValue: null
    },
    {
      provide: MAT_DIALOG_DATA,
      useValue: null
    },
    AddStudentComponent,
    AddHodComponent,
    AddDepartmentComponent,
    AddPlacementOfficerComponent
  ]
})

export class AdminLayoutModule { }

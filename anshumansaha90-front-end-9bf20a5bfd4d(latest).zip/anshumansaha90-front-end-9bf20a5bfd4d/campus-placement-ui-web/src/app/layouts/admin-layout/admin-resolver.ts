import { Injectable } from "@angular/core";
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from "@angular/router";
import { DepartmentService } from "src/app/department/department.service";
import { HodService } from "src/app/hod/hod.service";
import { PlacementService } from "src/app/placement-officer/placement.service";
import { StudentService } from "src/app/student/student.service";

export class AdminResolver {
}

@Injectable({ providedIn: 'root' })
export class viewStudentResolver implements Resolve<any> {
  constructor(private studentService: StudentService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.studentService.getStudentDetails();
  }
}

@Injectable({ providedIn: 'root' })
export class viewDepartmentResolver implements Resolve<any> {
  constructor(private departmentService: DepartmentService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.departmentService.getDepartmentDetails();
  }
}

@Injectable({ providedIn: 'root' })
export class viewHodResolver implements Resolve<any> {
  constructor(private hodService: HodService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.hodService.getHODDetails();
  }
}

@Injectable({ providedIn: 'root' })
export class viewPlacementResolver implements Resolve<any> {
  constructor(private placementService: PlacementService) { }
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.placementService.getPlacementDetails();
  }
}


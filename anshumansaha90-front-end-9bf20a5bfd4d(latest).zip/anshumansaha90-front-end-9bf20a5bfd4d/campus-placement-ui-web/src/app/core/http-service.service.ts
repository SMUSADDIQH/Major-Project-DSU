import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { Response } from '../model/response';

@Injectable({
  providedIn: 'root'
})
export class HttpServiceService {
  urlAddress: string = environment.apiBaseUrl;
  constructor(private http: HttpClient) {
  }

  post(body: any, restEndPoint: string): Observable<any> {
    const api: string = this.getApi(restEndPoint);
    return this.http.post(api, body);
  }

  get(params: any, restEndPoint: string): Observable<any> {
    let api = '';
    if(params) {
      api = this.getApi(restEndPoint+"/"+params);
    }
    else{
      api = this.getApi(restEndPoint);
    }
    return this.http.get(api);
  }

  delete(params: any, restEndPoint: string): Observable<Response> {
    const api: string = this.getApi(restEndPoint + "/" + params);
    return this.http.delete<Response>(api);
  }

  private getApi(restEndPoint: string): string {
    return this.urlAddress + restEndPoint;
  }

}

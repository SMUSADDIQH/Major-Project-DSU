import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {
  userRoles: string[] = ['student', 'hod', 'placement'];
  constructor(private authenticationService: AuthenticationService, private router: Router) {
    console.log('Auth Guard Service')
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const user = this.authenticationService.userValue;
    console.log('Auth Service {} : ' + user.loginUserId);

    if (user) {
      const role = this.userRoles.filter(role => user.userType === role);
      if (role) {
        return true;
      }
      else {
        this.router.navigate(['login']);
        return false;
      }
    }
    this.router.navigate(['login']);
    return false;
  }
}

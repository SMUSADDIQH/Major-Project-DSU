import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { StudentService } from 'src/app/student/student.service';
import { Students } from 'src/app/student/view-student/view-student.component';
import { JobsService } from '../jobs.service';

@Component({
  selector: 'app-applicable',
  templateUrl: './applicable.component.html',
  styleUrls: ['./applicable.component.css']
})
export class ApplicableComponent implements OnInit {
  displayedColumns: string[] = ['jobId', 'companyName', 'lastDate','isApplied','isApproved','actions'];
  dataSource!: ApplicableJobs[];
  studentData!: Students;
  constructor(
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private toastr: ToastrService,
    private jobService: JobsService,
    private studentService: StudentService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      if(response && response.student) {
        this.studentData = response.student;
        this.jobService.getApplicableJobs(this.studentData.studentId, this.studentData.departmentId, this.studentData.marksheetId).subscribe({
          next: (response) => {
            this.dataSource = response;
          }
        })
      }
      else {
        this.toastr.info('No Records Found!!!');
      }

    });
  }

  onApply(element: any) {

    const obj = {
      studentId: this.studentData.studentId,
      studentName: this.studentData.studentName,
      isApplied: true,
      isApproved: element.isApproved,
      jobId: element.jobId
    };
    this.jobService.applyJobs(obj).subscribe({
      next: (result) => {
        if (result.status === 'success') {
          this.toastr.success('Sucessfully Applied!', 'Success');
          this.refresh();
        }
      }
    });
  }

  refresh() {
    this.jobService.getApplicableJobs(this.studentData.studentId, this.studentData.departmentId, this.studentData.marksheetId)?.subscribe({
      next: (response) => {
        this.dataSource = response;
      }
    })
  }
}

export interface ApplicableJobs {
  jobId: number;
  companyName: number;
  lastDate: Date;
  isApplied: boolean;
  isApproved: boolean;
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Departments } from 'src/app/department/view-department/view-department.component';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { JobsService } from '../jobs.service';

@Component({
  selector: 'app-post-jobs',
  templateUrl: './post-jobs.component.html',
  styleUrls: ['./post-jobs.component.css']
})
export class PostJobsComponent implements OnInit {
  departments!: Departments[];
  placementId: number = 0;
  postJobForm = this.fb.group({
    companyName: ['', Validators.required],
    departmentId: ['', Validators.required],
    semister1: ['', Validators.required],
    semister2: ['', Validators.required],
    semister3: ['', Validators.required],
    semister4: ['', Validators.required],
    semister5: ['', Validators.required],
    semister6: ['', Validators.required],
    semister7: ['', Validators.required],
    semister8: ['', Validators.required],
  });
  constructor(
    private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService,
    private jobService: JobsService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      this.departments = response.departments;
    });
  }

  onSubmit() {
    const user = this.authenticationService.userValue;
    const obj = {
      placementId :  user.userId,
      companyName: this.postJobForm.value.companyName,
      departmentId: this.postJobForm.value.departmentId,
      semister1: this.postJobForm.value.semister1,
      semister2: this.postJobForm.value.semister2,
      semister3: this.postJobForm.value.semister3,
      semister4: this.postJobForm.value.semister4,
      semister5: this.postJobForm.value.semister5,
      semister6: this.postJobForm.value.semister6,
      semister7: this.postJobForm.value.semister7,
      semister8: this.postJobForm.value.semister8,
    };
    this.jobService.postJobs(obj).subscribe({
      next: (response) => {
        if(response && response['status'] === 'success') {
          this.toastr.success('inserted or updated successfully', 'Success');
        }
        else {
            this.toastr.error('Failed to insert or update','Failure')
        }
      },
      error: (err) => {
        this.toastr.error('Server Failure!!!', 'Failure');
      }
    })
  }
}

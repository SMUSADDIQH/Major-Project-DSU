import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApplicableJobs } from '../applicable/applicable.component';

@Component({
  selector: 'app-non-applicable',
  templateUrl: './non-applicable.component.html',
  styleUrls: ['./non-applicable.component.css']
})
export class NonApplicableComponent implements OnInit {
  displayedColumns: string[] = ['jobId', 'companyName', 'lastDate'];
  dataSource!: ApplicableJobs[];
  constructor(
    private activatedRoute: ActivatedRoute,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      if(response && response.nonApplicableJobs){
      this.dataSource = response.nonApplicableJobs;
    } else{
      this.toastr.info('No Records Found!!!');
    }
    });
  }
}

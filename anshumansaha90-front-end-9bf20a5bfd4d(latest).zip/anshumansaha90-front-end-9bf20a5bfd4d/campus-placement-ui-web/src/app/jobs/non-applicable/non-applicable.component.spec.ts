import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonApplicableComponent } from './non-applicable.component';

describe('NonApplicableComponent', () => {
  let component: NonApplicableComponent;
  let fixture: ComponentFixture<NonApplicableComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NonApplicableComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NonApplicableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

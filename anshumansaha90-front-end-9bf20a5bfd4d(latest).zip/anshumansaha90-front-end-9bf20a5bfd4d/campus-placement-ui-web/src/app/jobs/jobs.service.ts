import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { Response } from '../model/response';
import { AuthenticationService } from '../services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class JobsService {

  constructor(
    private httpService: HttpServiceService,
    private authenticationService: AuthenticationService
    ) { }

  getApplicableJobs(studentId: number, departmentId: number, marksheetId: number) {
      const params = studentId + '/' + departmentId + '/' +marksheetId;
      return this.httpService.get(params, 'listApplicableJobs');
  }

  getNonApplicableJobs() {
    const user = this.authenticationService.userValue;
    if(user) {
      const params = user.userId + '/' + user.loginUserId;
      return this.httpService.get(params, 'listNonApplicableJobs');
    }
  }

  postJobs(jobProfileData: any) {
    const body = {
      jobprofile : jobProfileData
    }
    return this.httpService.post(body, 'insertJobProfile');
  }

  getJobDetails() {
    return this.httpService.get(null,'listJobprofile');
  }

  approveJobs(jobProfileData: any) {
    const body = {
      approveJob: jobProfileData
    }
    return this.httpService.post(body, 'approveJobs');
  }

  applyJobs(jobProfileData: any) {
    const body = {
      applyjob: jobProfileData
    }
    return this.httpService.post(body, 'applyJobs');
  }

  deleteJobProfile(job_id: number): Observable<Response> {
    return this.httpService.delete(job_id, 'deleteJobProfile');
  }
}

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.css']
})
export class JobsComponent implements OnInit {
  module = '';

  navLinks: any[];
  activeLinkIndex = -1;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.data.subscribe(data => {
      if (data) {
        this.module = data['module'];
      }
    });

    this.navLinks = [
      {
        label: 'View Jobs',
        path: './view',
        module: ['admin', 'hod', 'placement'],
        index: 0
      }, {
        label: 'Post Jobs',
        path: './post',
        module: ['placement'],
        index: 1
      },
      {
        label: 'Applicable Jobs',
        path: './applicable',
        module: ['student'],
        index: 2
      },
      {
        label: 'Non-Applicable Jobs',
        path: './non-applicable',
        module: ['student'],
        index: 3
      }
    ];
  }

  ngOnInit(): void {
    console.log('JobsComponent');
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.path === '.' + this.router.url));
    });

    this.navLinks = this.navLinks.filter(links => links.module.includes(this.module));
  }
}

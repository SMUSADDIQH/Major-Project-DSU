import { animate, state, style, transition, trigger } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { JobsService } from '../jobs.service';


@Component({
  selector: 'app-view-jobs',
  templateUrl: './view-jobs.component.html',
  styleUrls: ['./view-jobs.component.css'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({ height: '0px', minHeight: '0' })),
      state('expanded', style({ height: '*' })),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class ViewJobsComponent implements OnInit {
  displayedColumns: string[] = ['jobId', 'companyName', 'jobDate', 'departmentName', 'semister1', 'semister2', 'semister3', 'semister4', 'semister5', 'semister6', 'semister7', 'semister8','delete'];
  innerDisplayedColumns: string[] = ['studentId', 'studentName', 'isApplied', 'isApproved', 'actions'];
  jobId: number = 0;
  dataSource!: JobDetails[];
  expandedElement!: JobDetails | null;
  constructor(
    private activatedRoute: ActivatedRoute,
    public dialog: MatDialog,
    private jobService: JobsService,
    private toastr: ToastrService
  ) { }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      this.dataSource = response.jobDetails;
    });
  }

  onApprove(studentId: any) {
    if (this.jobId !== 0) {
      const obj = {
        jobId: this.jobId,
        studentId: studentId
      };
      this.jobService.approveJobs(obj).subscribe({
        next: (response) => {
          if (response && response['status'] === 'success') {
            this.toastr.success('inserted or updated successfully', 'Success');
            this.refresh();
          }
        },
        error: (err) => {
          console.error(err);
          this.toastr.error('Failed to insert or update', 'Failure');
        }
      });
    }
  }

  setJobId(element: any) {
    this.jobId = element.jobId;
  }

  refresh() {
    this.jobService.getJobDetails().subscribe({
      next: (response) => {
        this.dataSource = response;
      }
    })
  }

  onDelete(element: any) {
    const message = 'Are you sure you want to delete Job Id: ' + element.jobId + '?';

    const dialogData = new ConfirmDialogModel("Confirm Action", message, false);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        const job_id = element.jobId;
        this.jobService.deleteJobProfile(job_id).subscribe({
          next: (result) => {
            if (result.status === 'success') {
              this.toastr.success('Sucessfully deleted!', 'Success');
              this.refresh();
            }
          }
        })
      }
    });
  }
}



export interface JobDetails {
  jobId: number;
  companyName: string;
  jobDate: Date;
  departmentName: string;
  semister1: number;
  semister2: number;
  semister3: number;
  semister4: number;
  semister5: number;
  semister6: number;
  semister7: number;
  semister8: number;
  applicableDetails: applicableDetail[];
}

export interface applicableDetail {
  studentId: number;
  studentName: string;
  isApplied: boolean;
  isApproved: boolean;
}

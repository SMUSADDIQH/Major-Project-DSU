import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private userSubject: BehaviorSubject<User>;
  public user: Observable<User>;

  constructor(private router: Router, private http: HttpServiceService, private toastr: ToastrService) {
    this.userSubject = new BehaviorSubject<User>(JSON.parse(sessionStorage.getItem('user') || '{}'))
    this.user = this.userSubject.asObservable()
  }

  login(username: string, password: string, userType: string): Observable<any> {
    const login = {
      login: {
        user_id: username,
        password: password,
        utype: userType
      }
    }
    return this.http.post(login, 'login');
  }

  public get userValue(): User {
    return this.userSubject.value
  }

  public set userValue(localUser) {
    this.userSubject.next(localUser);
  }

  logout() {
    // remove user from local storage to log user out
    sessionStorage.removeItem('user')
    const user: User = new User();
    this.userSubject.next(user);
    this.router.navigate(['/login']);
    this.toastr.success('Logged Out','Success');
  }
}

import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { AddStudentComponent, StudentEditModel } from '../add-student/add-student.component';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-view-student',
  templateUrl: './view-student.component.html',
  styleUrls: ['./view-student.component.css']
})
export class ViewStudentComponent implements OnInit {
  displayedColumns: string[] = ['studentId', 'studentName', 'departmentName', 'semister1', 'semister2', 'semister3', 'semister4', 'semister5', 'semister6', 'semister7', 'semister8', 'average', 'status', 'actions'];
  dataSource!: Students[];

  constructor(private activatedRoute: ActivatedRoute, public dialog: MatDialog, private studentService: StudentService, private toastr: ToastrService) { }

  ngOnInit(): void {
    console.log('ViewStudentComponent');
    this.activatedRoute.data.subscribe((response: any) => {
      this.dataSource = response.students;
    });
  }

  onEdit(element: any) {
    const message = 'Are you sure you want to edit' + element.studentName + '?';
    const dialogData = new StudentEditModel(element.studentName, element.departmentId, element.studentId);
    const dialogRef = this.dialog.open(AddStudentComponent, {
      maxWidth: "400px",
      data: dialogData
    });
  }

  onDelete(element: any) {
    const message = 'Are you sure you want to delete Student:- ' + element.studentName + '?';

    const dialogData = new ConfirmDialogModel("Confirm Action", message, false);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        const student_id = element.studentId;
        this.studentService.deleteStudent(student_id).subscribe({
          next: (result) => {
            if (result.status === 'success') {
              this.toastr.success('Sucessfully deleted!', 'Success');
              this.refresh();
            }
          }
        })
      }
    });
  }

  refresh() {
    this.studentService.getStudentDetails().subscribe({
      next: (response) => {
        if (response) {
          this.dataSource = response;
        }
      }
    })
  }
}

export interface Students {
  studentId: number;
  studentName: number;
  departmentName: number;
  departmantCode: string;
  departmentId: number;
  marksheetId: number;
  semister1: string;
  semister2: string;
  semister3: string;
  semister4: string;
  semister5: string;
  semister6: string;
  semister7: string;
  semister8: string;
  average: string;
  status: string;
}

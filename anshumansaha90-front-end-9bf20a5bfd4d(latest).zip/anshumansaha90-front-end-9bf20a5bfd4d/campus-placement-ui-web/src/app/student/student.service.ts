import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { Response } from '../model/response';
import { AuthenticationService } from '../services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  constructor(private httpService: HttpServiceService, private authenticationService: AuthenticationService) { }

  getStudentDetails(): Observable<any> {
    return this.httpService.get(null, 'listStudents');
  }

  deleteStudent(student_id: string): Observable<Response> {
    return this.httpService.delete(student_id, 'deleteStudent');
  }

  addStudent(studentName: string, departmentId: number) {
    const body = {
      students: {
        studentName: studentName,
        departmentId: departmentId,
        marksheetId: null
      }
    };
    return this.httpService.post(body,'insertStudent');
  }

  updateStudent(studentName: string, departmentId: number, studentId: number) {
    const body = {
      students: {
        studentId: studentId,
        studentName: studentName,
        departmentId: departmentId
      }
    };
    return this.httpService.post(body,'updateStudent');
  }

  getStudentDetailById() {
    const user = this.authenticationService.userValue;
    if(user) {
      const params = user.userId + '/' + user.loginUserId;
      return this.httpService.get(params, 'getStudentDetailById');
    }
  }
}

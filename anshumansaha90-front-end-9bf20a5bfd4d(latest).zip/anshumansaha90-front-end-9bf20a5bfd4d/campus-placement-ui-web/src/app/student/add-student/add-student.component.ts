import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { DepartmentService } from 'src/app/department/department.service';
import { Departments } from 'src/app/department/view-department/view-department.component';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  departments!: Departments[];
  isEdit: boolean = false;
  studentId: number = 0;
  studentRegistrationForm = this.fb.group({
    studentName: ['', Validators.required],
    departmentId: ['', Validators.required],
  });

  constructor(
    private activatedRoute: ActivatedRoute,
    private studentService: StudentService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AddStudentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: StudentEditModel,
    private departmentService: DepartmentService
  ) {
    if (data) {
      this.departmentService.getDepartmentDetails().subscribe((departments: any) => {
        this.departments = departments;
      });
      this.isEdit = true;
      this.studentRegistrationForm.setValue({ studentName: data.studentName, departmentId: data.departmentId });
      this.studentId = data.studentId;
    }
  }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      this.departments = response.departments;
    });
  }

  onSubmit() {
    const studentName = this.studentRegistrationForm.value.studentName;
    const departmentId = this.studentRegistrationForm.value.departmentId;
    const studentId = this.studentId;
    if (this.isEdit) {
      this.studentService.updateStudent(studentName, departmentId, studentId).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
    else {
      this.studentService.addStudent(studentName, departmentId).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
  }

  callbackResponse(response: any) {
    if (response) {
      const studentId = response['studentId'];
      const pwd = response['pwd'];
      this.toastr.success('inserted or updated successfully', 'Success');
      const message = 'Please save the provided user id and password:- \n User Id:- ' + studentId + '\n Password:- ' + pwd;
      const dialogData = new ConfirmDialogModel("Confirm Action", message, true);
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        maxWidth: "400px",
        data: dialogData,
        disableClose: true
      });
    }
  }

  callbackError(err: any) {
    console.error(err);
    this.toastr.error('Failed to insert or update', 'Failure');
  }
}

export class StudentEditModel {
  constructor(
    public studentName: string,
    public departmentId: string,
    public studentId: number
  ) {
  }
}

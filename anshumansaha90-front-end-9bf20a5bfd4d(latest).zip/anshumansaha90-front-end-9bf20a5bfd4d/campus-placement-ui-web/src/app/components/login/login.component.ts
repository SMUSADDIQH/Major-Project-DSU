import { Component, OnInit } from '@angular/core'
import { FormBuilder, FormGroup, Validators } from '@angular/forms'
import { ActivatedRoute, Router } from '@angular/router'
import { ToastrService } from 'ngx-toastr'
import { User } from 'src/app/model/user'
import { AuthenticationService } from 'src/app/services/authentication.service'

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string | undefined;
  error = '';
  utype = [{ name: 'Admin', code: 'admin' }, { name: 'HOD', code: 'hod' }, { name: 'Placement Officer', code: 'placement' }, { name: 'Student', code: 'student' }]
  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private toastr: ToastrService
  ) {
    if (this.authenticationService.userValue.loginUserId) {
      this.router.navigate(['/'])
    }
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required],
      userType: ['', Validators.required]
    })
  }

  ngOnInit(): void {
    const user = sessionStorage.getItem('user')
    if (user) {
      const userJson: User = JSON.parse(user)
      if (userJson.userType === 'admin') {
        this.router.navigate(['AdminModule'])
      }
    }
  }

  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls }

  onSubmit() {
    this.submitted = true

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return
    }

    this.loading = true
    this.authenticationService.login(this.f['username'].value, this.f['password'].value, this.f['userType'].value).subscribe({
      next: (response) => {
        if (response) {
          const localUser: User = new User()
          localUser.id = response.loginId;
          localUser.loginUserId = response.loginUserId;
          localUser.userId = response.userId;
          localUser.userType = response.utype;
          localUser.authdata = window.btoa(response.login_id + ':' + response.user_id + ':' + response.utype);
          sessionStorage.setItem('user', JSON.stringify(localUser));
          this.authenticationService.userValue = localUser;
          switch (response.utype.toString()) {
            case 'admin':
              this.router.navigate(['AdminModule']);
              break;
            case 'hod':
              this.router.navigate(['HodModule']);
              break;
              case 'student':
                this.router.navigate(['StudentModule']);
                break;
                case 'placement':
                  this.router.navigate(['PlacementModule']);
                  break;

            default:
              this.loading = false;
              this.toastr.error('Invalid Credentials!!!', 'ERROR');
              break;
          }
        }
      },
      error: (e) => {
        this.loading = false;
        this.toastr.error('Invalid Credentials!!!', 'ERROR');
      }
    })
  }

  clear() {
    this.submitted = false;
    this.loginForm.setValue({username: '',password: '', userType:''});
  }
}

import { NgModule } from '@angular/core';
import { MatModule } from '../module/mat/mat.module';

import { ConfirmationDialogComponent } from './confirmation-dialog/confirmation-dialog.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { PasswordChangeComponent } from './password-change/password-change.component';
import { SidebarComponent } from './sidebar/sidebar.component';

@NgModule({
  imports: [
    MatModule
  ],
  declarations: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    ConfirmationDialogComponent,
    PasswordChangeComponent
  ],
  exports: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    ConfirmationDialogComponent
  ]
})
export class ComponentsModule { }

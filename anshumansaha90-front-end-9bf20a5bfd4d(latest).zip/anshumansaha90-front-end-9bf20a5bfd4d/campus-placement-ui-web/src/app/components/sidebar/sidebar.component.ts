import { Component, Input, OnInit } from '@angular/core';

declare const $: any;
declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const adminRoutes: RouteInfo[] = [
  // { path: '/AdminModule/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
  { path: '/AdminModule/students', title: 'Students', icon: 'person', class: '' },
  { path: '/AdminModule/hod', title: 'HOD', icon: 'account_circle', class: '' },
  { path: '/AdminModule/placement', title: 'Placement Officer', icon: 'content_paste', class: '' },
  { path: '/AdminModule/department', title: 'Department', icon: 'description', class: '' },
];

export const hodRoutes: RouteInfo[] = [
  // { path: '/HodModule/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
  { path: '/HodModule/students', title: 'Students', icon: 'person', class: '' },
  { path: '/HodModule/jobs', title: 'Jobs', icon: 'work', class: '' }
];

export const studentRoutes: RouteInfo[] = [
  // { path: '/StudentModule/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
  { path: '/StudentModule/marksheet', title: 'MarkSheet', icon: 'insert_drive_file', class: '' },
  { path: '/StudentModule/jobs', title: 'Jobs', icon: 'work', class: '' },
];

export const placementRoutes: RouteInfo[] = [
  // { path: '/PlacementModule/dashboard', title: 'Dashboard', icon: 'dashboard', class: '' },
  { path: '/PlacementModule/jobs', title: 'Jobs', icon: 'work', class: '' }
];

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
  @Input() userType: string = '';

  menuItems!: any[];

  constructor() { }

  ngOnInit() {
    switch (this.userType.toUpperCase()) {
      case 'ADMIN':
        this.menuItems = adminRoutes.filter(menuItem => menuItem);
        break;

      case 'HOD':
        this.menuItems = hodRoutes.filter(menuItem => menuItem);
        break;

      case 'STUDENT':
        this.menuItems = studentRoutes.filter(menuItem => menuItem);
        break;

      case 'PLACEMENT':
        this.menuItems = placementRoutes.filter(menuItem => menuItem);
        break;

      default:
        console.error('Invalid UserType')
        break;
    }

  }
  isMobileMenu() {
    if ($(window).width() > 991) {
      return false;
    }
    return true;
  };
}

import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { AuthGuardService } from './core/auth-guard.service';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { HodLayoutComponent } from './layouts/hod-layout/hod-layout.component';
import { PlacementLayoutComponent } from './layouts/placement-layout/placement-layout.component';
import { StudentLayoutComponent } from './layouts/student-layout/student-layout.component';
import { AuthenticationService } from './services/authentication.service';


const routes: Routes = [
  {
    path: 'AdminModule',
    component: AdminLayoutComponent,
    loadChildren: () => import('./layouts/admin-layout/admin-layout.module').then(m => m.AdminLayoutModule),
    canActivate: [AuthGuardService]

  },
  {
    path: 'HodModule',
    component: HodLayoutComponent,
    loadChildren: () => import('./layouts/hod-layout/hod-layout.module').then(m => m.HodLayoutModule),
    canActivate: [AuthGuardService]

  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'StudentModule',
    component: StudentLayoutComponent,
    loadChildren: () => import('./layouts/student-layout/student-layout.module').then(m => m.StudentLayoutModule),
    canActivate: [AuthGuardService]
  },
  {
    path: 'PlacementModule',
    component: PlacementLayoutComponent,
    loadChildren: () => import('./layouts/placement-layout/placement-layout.module').then(m => m.PlacementLayoutModule),
    canActivate: [AuthGuardService]
  },

  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes, {
      useHash: true
    })],
  exports: [RouterModule],
  providers: [AuthenticationService, AuthGuardService]
})
export class AppRoutingModule { }

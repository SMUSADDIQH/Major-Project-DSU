import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { ToastrModule } from 'ngx-toastr';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ComponentsModule } from './components/components.module';
import { LoginComponent } from './components/login/login.component';
import { AuthGuardService } from './core/auth-guard.service';
import { JobsComponent } from './jobs/jobs.component';
import { AdminLayoutComponent } from './layouts/admin-layout/admin-layout.component';
import { HodLayoutComponent } from './layouts/hod-layout/hod-layout.component';
import { PlacementLayoutComponent } from './layouts/placement-layout/placement-layout.component';
import { StudentLayoutComponent } from './layouts/student-layout/student-layout.component';
import { MatModule } from './module/mat/mat.module';


@NgModule({
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    HodLayoutComponent,
    StudentLayoutComponent,
    PlacementLayoutComponent,
    LoginComponent,
    JobsComponent
  ],
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    ToastrModule.forRoot(),
    MatModule
  ],
  providers: [AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { DepartmentService } from 'src/app/department/department.service';
import { Departments } from 'src/app/department/view-department/view-department.component';
import { HodService } from '../hod.service';

@Component({
  selector: 'app-add-hod',
  templateUrl: './add-hod.component.html',
  styleUrls: ['./add-hod.component.css']
})
export class AddHodComponent implements OnInit {
  departments!: Departments[];
  isEdit: boolean = false;
  hodId: number = 0;
  hodRegistrationForm = this.fb.group({
    hodName: ['', Validators.required],
    departmentId: ['', Validators.required],
    contactNumber: ['', Validators.required]
  });
  constructor(
    private activatedRoute: ActivatedRoute,
    private hodService: HodService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AddHodComponent>,
    @Inject(MAT_DIALOG_DATA) public data: HodEditModel,
    private departmentService: DepartmentService
  ) {
    if (data) {
      this.departmentService.getDepartmentDetails().subscribe((departments: any) => {
        this.departments = departments;
      });
      this.isEdit = true;
      this.hodRegistrationForm.setValue({ hodName: data.hodName, departmentId: data.departmentId, contactNumber: data.contactNumber });
      this.hodId = data.hodId;
    }
  }

  ngOnInit(): void {
    this.activatedRoute.data.subscribe((response: any) => {
      this.departments = response.departments;
    });
  }

  onSubmit() {
    const hodName = this.hodRegistrationForm.value.hodName;
    const departmentId = this.hodRegistrationForm.value.departmentId;
    const contactNumber = this.hodRegistrationForm.value.contactNumber;
    const hodId = this.hodId;

    if (this.isEdit) {
      this.hodService.updateHod(hodName, contactNumber, departmentId, hodId).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
    else {
      this.hodService.addHod(hodName, departmentId, contactNumber).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
  }

  callbackResponse(response: any) {
    if (response) {
      const hodId = response['hodId'];
      const pwd = response['pwd'];
      this.toastr.success('inserted or updated successfully', 'Success');
      const message = 'Please save the provided user id and password \n User Id:- ' + hodId + '\n Password:- ' + pwd;
      const dialogData = new ConfirmDialogModel("Information", message, true);
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        maxWidth: "400px",
        data: dialogData
      });
    }
  }

  callbackError(err: any) {
    console.error(err);
    this.toastr.error('Failed to insert or update', 'Failure');
  }
}

export class HodEditModel {
  constructor(
    public hodName: string,
    public contactNumber: string,
    public departmentId: number,
    public hodId: number
  ) {
  }
}

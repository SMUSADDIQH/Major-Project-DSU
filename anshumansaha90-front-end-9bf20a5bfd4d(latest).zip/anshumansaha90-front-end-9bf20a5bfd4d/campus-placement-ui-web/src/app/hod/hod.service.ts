import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { Response } from '../model/response';
import { AuthenticationService } from '../services/authentication.service';

@Injectable({
  providedIn: 'root'
})
export class HodService {

  constructor(private httpService: HttpServiceService, private authenticationService: AuthenticationService) { }

  getHODDetails(): Observable<any> {
    return this.httpService.get(null, 'listHod');
  }

  deleteHOD(hod_id: string): Observable<Response> {
    return this.httpService.delete(hod_id, 'deleteHod');
  }

  addHod(hodName: string, departmentId: number, contactNumber: string) {
    const body = {
      hod: {
        hodName: hodName,
        departmentId: departmentId,
        contactNumber: contactNumber
      }
    };
    return this.httpService.post(body, 'insertHod');
  }

  updateHod(hodName: string, contactNumber: string, departmentId: number, hodId: number) {
    const body = {
      hod: {
        hodName: hodName,
        departmentId: departmentId,
        contactNumber: contactNumber,
        hodId: hodId
      }
    };
    return this.httpService.post(body, 'updateHod');
  }

  getStudentDetailsByHodId() {
    const user = this.authenticationService.userValue;
    if (user) {
      const params = user.userId;
      return this.httpService.get(params, 'getStudentDetailByHodId');
    }
  }

  getHodDetailsByHodId() {
    const user = this.authenticationService.userValue;
    if (user) {
      const params = user.userId;
      return this.httpService.get(params, 'getHodDetailsByHodId');
    }
  }

  getJobprofileByDepartmentId() {
    const hod = sessionStorage.getItem('hod');
    if(hod) {
      const hodParsed = JSON.parse(hod);
      const params = hodParsed.departmentId;
      return this.httpService.get(params, 'listJobprofileByDepartmentId');
    }
  }
}

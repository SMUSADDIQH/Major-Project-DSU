import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { AddHodComponent, HodEditModel } from '../add-hod/add-hod.component';
import { HodService } from '../hod.service';

@Component({
  selector: 'app-view-hod',
  templateUrl: './view-hod.component.html',
  styleUrls: ['./view-hod.component.css']
})
export class ViewHodComponent implements OnInit {
  displayedColumns: string[] = ['hodId', 'hodName', 'hodContactNumber','departmentName','sts','actions'];
  dataSource!: Hods[];

  constructor(private activatedRoute: ActivatedRoute, public dialog: MatDialog, private hodService: HodService, private toastr: ToastrService) { }
  ngOnInit(): void {
    console.log('ViewDepartmentComponent');
    this.activatedRoute.data.subscribe((response: any) => {
      this.dataSource = response.hod;
    });
  }

  onEdit(element: any) {
    const message = 'Are you sure you want to edit'+ element.hodName+'?';
    const dialogData = new HodEditModel(element.hodName, element.hodContactNumber, element.departmentId, element.hodId);
    const dialogRef = this.dialog.open(AddHodComponent, {
      maxWidth: "400px",
      data: dialogData
    });
  }

  onDelete(element: any) {
    const message = 'Are you sure you want to delete Hod:- ' + element.hodName + '?';

    const dialogData = new ConfirmDialogModel("Confirm Action", message, false);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        const hod_id = element.hodId;
        this.hodService.deleteHOD(hod_id).subscribe({
          next: (result) => {
            if (result.status === 'success') {
              this.toastr.success('Sucessfully deleted!', 'Success');
              this.refresh();
            }
          }
        })
      }
    });
  }

  refresh() {
    this.hodService.getHODDetails().subscribe({
      next: (response) => {
        if (response) {
          this.dataSource = response;
        }
      }
    })
  }

}

export interface Hods {
  hodId: number;
  hodName: string;
  hodContactNumber: string;
  departmentName: string;
  departmentId: number;
  status: string;
}

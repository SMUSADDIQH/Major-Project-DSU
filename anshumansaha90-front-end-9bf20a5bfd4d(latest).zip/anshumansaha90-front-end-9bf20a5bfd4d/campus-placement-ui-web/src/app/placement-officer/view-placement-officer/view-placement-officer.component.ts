import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { AddPlacementOfficerComponent, PlacementEditModel } from '../add-placement-officer/add-placement-officer.component';
import { PlacementService } from '../placement.service';

@Component({
  selector: 'app-view-placement-officer',
  templateUrl: './view-placement-officer.component.html',
  styleUrls: ['./view-placement-officer.component.css']
})
export class ViewPlacementOfficerComponent implements OnInit {
  displayedColumns: string[] = ['placementId', 'placementName', 'contactNumber', 'status', 'actions'];
  dataSource!: Placement[];

  constructor(private activatedRoute: ActivatedRoute, public dialog: MatDialog, private placementService: PlacementService, private toastr: ToastrService) { }
  ngOnInit(): void {
    console.log('ViewPlacementOfficerComponent');
    this.activatedRoute.data.subscribe((response: any) => {
      this.dataSource = response.placement;
    });
  }

  onEdit(element: any) {
    const message = 'Are you sure you want to edit' + element.placementName + '?';
    const dialogData = new PlacementEditModel(element.placementName, element.contactNumber, element.placementId);
    const dialogRef = this.dialog.open(AddPlacementOfficerComponent, {
      maxWidth: "400px",
      data: dialogData
    });
  }

  onDelete(element: any) {
    const message = 'Are you sure you want to delete Placement:- ' + element.placementName + '?';

    const dialogData = new ConfirmDialogModel("Confirm Action", message, false);

    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      maxWidth: "400px",
      data: dialogData
    });

    dialogRef.afterClosed().subscribe(dialogResult => {
      if (dialogResult) {
        const placementId = element.placementId;
        this.placementService.deletePlacement(placementId).subscribe({
          next: (result) => {
            if (result.status === 'success') {
              this.toastr.success('Sucessfully deleted!', 'Success');
              this.refresh();
            }
          }
        })
      }
    });
  }

  refresh() {
    this.placementService.getPlacementDetails().subscribe({
      next: (response) => {
        if (response) {
          this.dataSource = response;
        }
      }
    })
  }

}

export interface Placement {
  placementId: number;
  placementName: string;
  contactNumber: string;
  status: string;
}

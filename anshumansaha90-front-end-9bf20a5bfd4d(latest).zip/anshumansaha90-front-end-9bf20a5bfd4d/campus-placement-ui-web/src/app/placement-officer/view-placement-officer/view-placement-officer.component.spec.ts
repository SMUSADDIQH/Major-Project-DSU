import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewPlacementOfficerComponent } from './view-placement-officer.component';

describe('ViewPlacementOfficerComponent', () => {
  let component: ViewPlacementOfficerComponent;
  let fixture: ComponentFixture<ViewPlacementOfficerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewPlacementOfficerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewPlacementOfficerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlacementOfficerComponent } from './placement-officer.component';

describe('PlacementOfficerComponent', () => {
  let component: PlacementOfficerComponent;
  let fixture: ComponentFixture<PlacementOfficerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlacementOfficerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlacementOfficerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

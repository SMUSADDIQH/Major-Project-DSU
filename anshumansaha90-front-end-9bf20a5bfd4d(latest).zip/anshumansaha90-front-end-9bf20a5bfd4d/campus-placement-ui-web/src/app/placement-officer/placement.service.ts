import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpServiceService } from '../core/http-service.service';
import { Response } from '../model/response';

@Injectable({
  providedIn: 'root'
})
export class PlacementService {

  constructor(private httpService: HttpServiceService) { }

  getPlacementDetails(): Observable<any> {
    return this.httpService.get(null, 'listPlacement');
  }

  deletePlacement(placementId: string): Observable<Response> {
    return this.httpService.delete(placementId, 'deletePlacement');
  }

  addPlacement(placementName: string, contactNumber: string) {
    const body = {
      placement: {
        placementName: placementName,
        contactNumber: contactNumber
      }
    };
    return this.httpService.post(body, 'insertPlacement');
  }

  updatePlacement(placementName: string, contactNumber: string, placementId: number) {
    const body = {
      placement: {
        placementName: placementName,
        contactNumber: contactNumber,
        placementId: placementId
      }
    };
    return this.httpService.post(body, 'updatePlacement');
  }
}

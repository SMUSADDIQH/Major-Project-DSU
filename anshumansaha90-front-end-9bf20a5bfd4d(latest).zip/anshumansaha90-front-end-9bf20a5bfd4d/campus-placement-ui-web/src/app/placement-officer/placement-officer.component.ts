import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-placement-officer',
  templateUrl: './placement-officer.component.html',
  styleUrls: ['./placement-officer.component.css']
})
export class PlacementOfficerComponent implements OnInit {
  navLinks: any[];
  activeLinkIndex = -1;
  constructor(private router: Router) {
    this.navLinks = [
      {
          label: 'View Placement Officer',
          path: './view',
          index: 0
      }, {
          label: 'Add Placement Officer',
          path: './add',
          index: 1
      }
  ];
  }

  ngOnInit(): void {
    console.log('PlacementOfficerComponent');
    this.router.events.subscribe((res) => {
      this.activeLinkIndex = this.navLinks.indexOf(this.navLinks.find(tab => tab.path === '.' + this.router.url));
  });
  }
}

import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationDialogComponent, ConfirmDialogModel } from 'src/app/components/confirmation-dialog/confirmation-dialog.component';
import { PlacementService } from '../placement.service';

@Component({
  selector: 'app-add-placement-officer',
  templateUrl: './add-placement-officer.component.html',
  styleUrls: ['./add-placement-officer.component.css']
})
export class AddPlacementOfficerComponent implements OnInit {
  isEdit: boolean = false;
  placementId: number = 0;
  placementRegistrationForm = this.fb.group({
    placementName: ['', Validators.required],
    contactNumber: ['', [Validators.required, Validators.maxLength(10)]]
  });
  constructor(
    private activatedRoute: ActivatedRoute,
    private placementService: PlacementService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    public dialogRef: MatDialogRef<AddPlacementOfficerComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PlacementEditModel
  ) {
    if (data) {
      this.isEdit = true;
      this.placementRegistrationForm.setValue({ placementName: data.placementName, contactNumber: data.contactNumber });
      this.placementId = data.placementId;
    }
  }

  ngOnInit(): void {
    console.log('AddPlacementOfficerComponent');
  }

  onSubmit() {
    const placementName = this.placementRegistrationForm.value.placementName;
    const contactNumber = this.placementRegistrationForm.value.contactNumber;
    const placementId = this.placementId;

    if (this.isEdit) {
      this.placementService.updatePlacement(placementName, contactNumber, placementId).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
    else {
      this.placementService.addPlacement(placementName, contactNumber).subscribe({
        next: (response) => this.callbackResponse(response), error: (err) => this.callbackError(err)
      });
    }
  }

  callbackResponse(response: any) {
    if (response) {
      const placementId = response['placementId'];
      const pwd = response['pwd'];
      this.toastr.success('inserted or updated successfully', 'Success');
      const message = 'Please save the provided user id and password \n User Id:- ' + placementId + '\n Password:- ' + pwd;
      const dialogData = new ConfirmDialogModel("Information", message, true);
      const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
        maxWidth: "400px",
        data: dialogData
      });
    }
  }

  callbackError(err: any) {
    console.error(err);
    this.toastr.error('Failed to insert or update', 'Failure');
  }

  get contactNumber() {
    return this.placementRegistrationForm.get('contactNumber');
  }

  get placementName() {
    return this.placementRegistrationForm.get('placementName');
  }
}

export class PlacementEditModel {
  constructor(
    public placementName: string,
    public contactNumber: string,
    public placementId: number
  ) {
  }
}

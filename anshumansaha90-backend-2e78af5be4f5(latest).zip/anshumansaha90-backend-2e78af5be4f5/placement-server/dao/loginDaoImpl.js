const dbSelectExecution = require('../database/select');

async function validate(user_id, password, utype) {
    const result = await dbSelectExecution.selectLoginTable(user_id, password, utype);
    return result;
}

module.exports = {
    validate
}
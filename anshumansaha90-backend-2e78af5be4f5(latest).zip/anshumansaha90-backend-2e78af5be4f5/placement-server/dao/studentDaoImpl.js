const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');
const dbDeleteExecution = require('../database/delete');
const dbUpdateExecution = require('../database/update');

async function insertStudentDao(studentEntity) {
    const result = await dbInsertExecution.insertStudentTable(studentEntity);
    return result;
}

async function fetchStudentsDao() {
    const result = await dbSelectExecution.selectStudentTable();
    return result
}

async function deleteStudentDao(student_id) {
    const result = await dbDeleteExecution.deleteStudentTable(student_id);
    return result
}

async function updateStudentDao(studentEntity) {
    const result = await dbUpdateExecution.updateStudentTable(studentEntity);
    return result;
}

async function fetchStudentbyId(studentId, loginUserId) {
    return await dbSelectExecution.fetchStudentById(studentId, loginUserId);
}

async function fetchApplicableJobs(studentId, departmentId, marksheetId) {
    return await dbSelectExecution.fetchApplicableJobs(studentId, departmentId, marksheetId);
}

async function fetchNonApplicableJobs(studentId, loginUserId) {
    return await dbSelectExecution.fetchNonApplicableJobs(studentId, loginUserId);
}

async function applyjob(jobDetailObject, jobId) {
    const jsonObject = JSON.stringify(jobDetailObject);
    return await dbInsertExecution.applyjob(jsonObject, jobId);
}

module.exports = {
    insertStudentDao,
    fetchStudentsDao,
    deleteStudentDao,
    updateStudentDao,
    fetchStudentbyId,
    fetchApplicableJobs,
    fetchNonApplicableJobs,
    applyjob
}
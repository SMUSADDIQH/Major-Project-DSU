const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');
const dbUpdateExecution = require('../database/update');
const dbDeleteExecution = require('../database/delete');

async function insertjobProfileDao(jobprofileObject) {
    const jsonObject = JSON.stringify(jobprofileObject);
    const result = await dbInsertExecution.insertJobProfileTable(jsonObject);
    return result;
}

async function fetchJobprofileDao() {
    const result = await dbSelectExecution.selectJobprofileTable();
    return result;
}

async function fetchJobProfileById(jobId) {
    return await dbSelectExecution.fetchJobProfileById(jobId);
}

async function updateJobProfileTable(app_dtl, jobId) {
    const jsonObject = JSON.stringify(app_dtl);
    return await dbUpdateExecution.updateJobProfileTable(jsonObject, jobId);
}

async function fetchJobProfileByDepartmentId(departmentId) {
    return await dbSelectExecution.fetchJobProfileByDepartmentId(departmentId);
}

async function deleteJobProfile(jobId) {
    return await dbDeleteExecution.deleteJobProfileTable(jobId);
}

module.exports = {
    insertjobProfileDao,
    fetchJobprofileDao,
    fetchJobProfileById,
    updateJobProfileTable,
    fetchJobProfileByDepartmentId,
    deleteJobProfile
}
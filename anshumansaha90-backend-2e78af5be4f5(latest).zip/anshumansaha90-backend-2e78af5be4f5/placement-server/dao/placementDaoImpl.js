const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');
const dbDeleteExecution = require('../database/delete');
const dbUpdateExecution = require('../database/update');

async function insertPlacementDao(placementEntity) {
    const result = await dbInsertExecution.insertPlacementTable(placementEntity);
    return result;
}

async function fetchPlacementDao() {
    const result = await dbSelectExecution.selectPlacementTable();
    return result
}

async function deletePlacementDao(placementId) {
    const result = await dbDeleteExecution.deletePlacementTable(placementId);
    return result
}

async function updatePlacementDao(placementEntity) {
    const result = await dbUpdateExecution.updatePlacementTable(placementEntity);
    return result;
}

module.exports = {
    insertPlacementDao,
    fetchPlacementDao,
    deletePlacementDao,
    updatePlacementDao
}
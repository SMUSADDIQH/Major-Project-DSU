const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');
const dbDeleteExecution = require('../database/delete');
const dbUpdateExecution = require('../database/update');

async function insertHodDao(hodEntity) {
    const result = await dbInsertExecution.insertHodTable(hodEntity);
    return result;
}

async function fetchHodDao() {
    const result = await dbSelectExecution.selectHodTable();
    return result
}

async function deleteHodDao(hodId) {
    const result = await dbDeleteExecution.deleteHodTable(hodId);
    return result;
}

async function updateHodDao(hodEntity) {
    const result = await dbUpdateExecution.updateHodTable(hodEntity);
    return result;
}

async function fetchStudentByHodId(hodId) {
    return await dbSelectExecution.fetchStudentByHodId(hodId);
}

async function fetchHodDetailsByHodId(hodId) {
return await dbSelectExecution.fetchHodDetailsByHodId(hodId);
}
module.exports = {
    insertHodDao,
    fetchHodDao,
    deleteHodDao,
    updateHodDao,
    fetchStudentByHodId,
    fetchHodDetailsByHodId
}
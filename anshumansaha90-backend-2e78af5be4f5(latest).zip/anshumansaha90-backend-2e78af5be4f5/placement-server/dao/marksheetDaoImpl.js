const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');

async function insertMarksheetDao(marksheetObject) {
    const jsonObject = JSON.stringify(marksheetObject);
    const result = await dbInsertExecution.insertMarksheetTable(jsonObject);
    return result;
}

async function fetchMarksheetDao() {
    const result = await dbSelectExecution.selectMarksheetTable();
    return result
}

module.exports = {
    insertMarksheetDao,
    fetchMarksheetDao
}
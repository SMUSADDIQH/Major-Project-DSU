const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');


async function insertCriteriaDao(criteriaEntity) {
    const result = await dbInsertExecution.insertCriteriaTable(criteriaEntity);
    return result;
}

async function fetchCriteriaDao() {
    const result = await dbSelectExecution.selectCriteriaTable();
    return result
}

module.exports = {
    insertCriteriaDao,
    fetchCriteriaDao
}
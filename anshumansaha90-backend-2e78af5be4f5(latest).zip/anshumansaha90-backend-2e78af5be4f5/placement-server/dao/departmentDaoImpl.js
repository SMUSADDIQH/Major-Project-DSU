const dbInsertExecution = require('../database/insert');
const dbSelectExecution = require('../database/select');
const dbDeleteExecution = require('../database/delete');
const dbUpdateExecution = require('../database/update');

async function insertDepartmentDao(departmentEntity) {
    const result = await dbInsertExecution.insertDepartmentTable(departmentEntity);
    return result;
}

async function fetchDepartmentDao() {
    const result = await dbSelectExecution.selectDepartmentTable();
    return result
}

async function deleteDepartmentDao(department_id) {
    const result = await dbDeleteExecution.deleteDepartmentTable(department_id);
    return result
}

async function updateDepartmentDao(departmentEntity) {
    const result = await dbUpdateExecution.updateDepartmentTable(departmentEntity);
    return result;
}

module.exports = {
    insertDepartmentDao,
    fetchDepartmentDao,
    deleteDepartmentDao,
    updateDepartmentDao
}
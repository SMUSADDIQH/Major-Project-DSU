exports.setPlacementId = function (placementId) {
    this.placementId = placementId;
}

exports.getPlacementId = function () {
    return this.placementId;
}

exports.setPlacementName = function (placementName) {
    this.placementName = placementName;
}

exports.getPlacementName = function () {
    return this.placementName;
}

exports.setContactNumber = function (contactNumber) {
    this.contactNumber = contactNumber;
}

exports.getContactNumber = function () {
    return this.contactNumber;
}

exports.setStatus = function (status) {
    this.status = status;
}

exports.getStatus = function () {
    return this.status;
}
exports.setLoginId = function (login_id) {
    this.login_id = login_id;
}

exports.getLoginId = function () {
    return this.login_id;
}

exports.setUserId = function (user_id) {
    this.user_id = user_id;
}

exports.getUserId = function () {
    return this.user_id;
}

exports.setPassword = function (password) {
    this.password = password;
}

exports.getUserType = function () {
    return this.utype;
}

exports.setUserType= function (utype) {
    this.utype = utype;
}

exports.getHodId = function () {
    return this.hodId;
}
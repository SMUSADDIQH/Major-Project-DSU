exports.setStudentsName = function(studentName) {
    this.studentName = studentName;
}

exports.getStudentName = function () {
    return this.studentName;
}

exports.setDepartmentId = function(departmentId) {
    this.departmentId = departmentId;
}

exports.getDepartmentId = function() {
    return this.departmentId;
}

exports.setMarksheetId = function (marksheetId) {
this.marksheetId = marksheetId;
}

exports.getMarksheetId = function () {
    return this.marksheetId;
}

exports.setStudentId = function (studentId) {
    this.studentId = studentId;
    }
    
    exports.getStudentId = function () {
        return this.studentId;
    }
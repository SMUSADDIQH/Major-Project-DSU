exports.setJobId = function (jobId) {
    this.jobId = jobId;
}

exports.getJobId = function () {
    return this.jobId;
}

exports.setCompanyName = function (companyName) {
    this.companyName = companyName;
}

exports.getCompanyName = function () {
    return this.companyName;
}

exports.setCriteriaId = function (criteriaId) {
    this.criteriaId = criteriaId;
}

exports.getCriteriaId = function () {
    return this.criteriaId;
}

exports.setJobDate = function (jobDate) {
    this.jodDate = jobDate;
}

exports.getJobDate = function () {
    return this.jobDate;
}

exports.setDepartmentId = function (departmentId) {
    this.departmentId = departmentId;
}

exports.getDepartmentId = function () {
    return this.departmentId;
}

exports.setPlacementId = function (placementId) {
    this.placementId = placementId;
}

exports.getPlacementId = function () {
    return this.placementId;
}

exports.setSemister1 = function (semister1) {
    this.semister1 = semister1;
}

exports.getSemister1 = function () {
    return this.semister1;
}

exports.setSemister2 = function (semister2) {
    this.semister2 = semister2;
}

exports.getSemister2 = function () {
    return this.semister2;
}

exports.setSemister3 = function (semister3) {
    this.semister3 = semister3;
}

exports.getSemister3 = function () {
    return this.semister3;
}

exports.setSemister4 = function (semister4) {
    this.semister4 = semister4;
}

exports.getSemister4 = function () {
    return this.departmentCode;
}

exports.setSemister5 = function (semister5) {
    this.semister5 = semister5;
}

exports.getSemister5 = function () {
    return this.semister5;
}

exports.setSemister6 = function (semister6) {
    this.semister6 = semister6;
}

exports.getSemister6 = function () {
    return this.semister6;
}

exports.setSemister7 = function (semister7) {
    this.semister7 = semister7;
}

exports.getSemister7 = function () {
    return this.semister7;
}

exports.setSemister8 = function (semister8) {
    this.semister8 = semister8;
}

exports.getSemister8 = function () {
    return this.semister8;
}

exports.setAverage = function (average) {
    this.average = average;
}

exports.getAverage = function () {
    return this.average;
}

exports.getObject = function (jobprofileEntity) {
    const obj = {
        jobId: jobprofileEntity.jobId === undefined ? null : jobprofileEntity.jobId,
        criteriaId: jobprofileEntity.criteriaId === undefined ? null : jobprofileEntity.criteriaId,
        companyName: jobprofileEntity.companyName,
        departmentId: jobprofileEntity.departmentId,
        placementId: jobprofileEntity.placementId,
        semister1: jobprofileEntity.semister1,
        semister2: jobprofileEntity.semister2,
        semister3: jobprofileEntity.semister3,
        semister4: jobprofileEntity.semister4,
        semister5: jobprofileEntity.semister5,
        semister6: jobprofileEntity.semister6,
        semister7: jobprofileEntity.semister7,
        semister8: jobprofileEntity.semister8
    }
    return obj;
}

exports.setCriteriaId = function (criteriaId) {
    this.criteriaId = criteriaId;
}

exports.getCriteriaId = function () {
    return this.criteriaId;
}

exports.setSemister_1 = function (semister_1) {
    this.semister_1 = semister_1;
}

exports.getSemister_1 = function () {
    return this.semister_1;
}

exports.setSemister_2 = function (semister_2) {
    this.semister_2 = semister_2;
}

exports.getSemister_2 = function () {
    return this.semister_2;
}

exports.setSemister_3 = function (semister_3) {
    this.semister_3 = semister_3;
}

exports.getSemister_3 = function () {
    return this.semister_3;
}

exports.setSemister_4 = function (semister_4) {
    this.semister_4 = semister_4;
}

exports.getSemister_4 = function () {
    return this.departmentCode;
}

exports.setSemister_5 = function (semister_5) {
    this.semister_5 = semister_5;
}

exports.getSemister_5 = function () {
    return this.semister_5;
}

exports.setSemister_6 = function (semister_6) {
    this.semister_6 = semister_6;
}

exports.getSemister_6 = function () {
    return this.semister_6;
}

exports.setSemister_7 = function (semister_7) {
    this.semister_7 = semister_7;
}

exports.getSemister_7 = function () {
    return this.semister_7;
}

exports.setSemister_8 = function (semister_8) {
    this.semister_8 = semister_8;
}

exports.getSemister_8 = function () {
    return this.semister_8;
}

exports.setAverage = function (average) {
    this.average = average;
}

exports.getAverage = function () {
    return this.average;
}
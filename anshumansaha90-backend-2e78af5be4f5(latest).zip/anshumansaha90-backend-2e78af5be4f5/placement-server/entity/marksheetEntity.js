exports.setMarksheetId = function (marksheetId) {
    this.marksheetId = marksheetId;
}

exports.getMarksheetId = function () {
    return this.marksheetId;
}

exports.setStudentId = function (studentId) {
    this.studentId = studentId;
}

exports.getStudentId = function () {
    return this.studentId;
}

exports.setLoginUserId = function (loginUserId) {
    this.loginUserId = loginUserId;
}

exports.getLoginUserId = function () {
    return this.loginUserId;
}

exports.setSemister1 = function (semister1) {
    this.semister1 = semister1;
}

exports.getSemister1 = function () {
    return this.semister1;
}

exports.setSemister2 = function (semister2) {
    this.semister2 = semister2;
}

exports.getSemister2 = function () {
    return this.semister2;
}

exports.setSemister3 = function (semister3) {
    this.semister3 = semister3;
}

exports.getSemister3 = function () {
    return this.semister3;
}

exports.setSemister4 = function (semister4) {
    this.semister4 = semister4;
}

exports.getSemister4 = function () {
    return this.departmentCode;
}

exports.setSemister5 = function (semister5) {
    this.semister5 = semister5;
}

exports.getSemister5 = function () {
    return this.semister5;
}

exports.setSemister6 = function (semister6) {
    this.semister6 = semister6;
}

exports.getSemister6 = function () {
    return this.semister6;
}

exports.setSemister7 = function (semister7) {
    this.semister7 = semister7;
}

exports.getSemister7 = function () {
    return this.semister7;
}

exports.setSemister8 = function (semister8) {
    this.semister8 = semister8;
}

exports.getSemister8 = function () {
    return this.semister8;
}

exports.setAverage = function (average) {
    this.average = average;
}

exports.getAverage = function () {
    return this.average;
}

exports.getObject = function (marksheetEntity) {
    const obj = {
        marksheetId: marksheetEntity.marksheetId === undefined ? null : marksheetEntity.marksheetId,
        studentId: marksheetEntity.studentId,
        loginUserId: marksheetEntity.loginUserId,
        semister1: marksheetEntity.semister1,
        semister2: marksheetEntity.semister2,
        semister3: marksheetEntity.semister3,
        semister4: marksheetEntity.semister4,
        semister5: marksheetEntity.semister5,
        semister6: marksheetEntity.semister6,
        semister7: marksheetEntity.semister7,
        semister8: marksheetEntity.semister8
    }
    return obj;
}

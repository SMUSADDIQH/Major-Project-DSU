exports.setDepartmentName = function (departmentName) {
    this.departmentName = departmentName;
}

exports.getDepartmentName = function () {
    return this.departmentName;
}

exports.setDepartmentId = function (departmentId) {
    this.departmentId = departmentId;
}

exports.getDepartmentId = function () {
    return this.departmentId;
}

exports.setDepartmentCode = function (departmentCode) {
    this.departmentCode = departmentCode;
}

exports.getDepartmentCode = function () {
    return this.departmentCode;
}
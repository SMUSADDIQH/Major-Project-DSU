exports.setHodId = function (hodId) {
    this.hodId = hodId;
}

exports.getHodId = function () {
    return this.hodId;
}

exports.setDepartmentId = function (departmentId) {
    this.departmentId = departmentId;
}

exports.getDepartmentId = function () {
    return this.departmentId;
}

exports.setHodName = function (hodName) {
    this.hodName = hodName;
}

exports.getHodName = function () {
    return this.hodName;
}

exports.setContactNumber = function (contactNumber) {
    this.contactNumber = contactNumber;
}

exports.getContactNumber = function () {
    return this.contactNumber;
}

exports.setStatus = function (status) {
    this.status = status;
}

exports.getStatus = function () {
    return this.status;
}
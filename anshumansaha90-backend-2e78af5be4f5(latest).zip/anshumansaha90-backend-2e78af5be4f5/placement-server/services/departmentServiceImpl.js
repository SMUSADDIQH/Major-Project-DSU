const departmentDao = require('../dao/departmentDaoImpl');

async function insertDepartment(departments) {
    if (departments != null) {
        let departmentEntity = require('../entity/departmentEntity');
        departmentEntity.setDepartmentName(departments.departmentName);
        departmentEntity.setDepartmentCode(departments.departmentCode);
        const result = await departmentDao.insertDepartmentDao(departmentEntity);
        if (result == 1) {
            return 'S';
        }
        else {
            return 'F';
        }
    }
}

async function fetchDepartmentDetails() {
    return await departmentDao.fetchDepartmentDao();
}

async function deleteDepartment(department_id) {
    return await departmentDao.deleteDepartmentDao(department_id);
}

async function updateDepartment(departments) {
    if (departments != null) {
        let departmentEntity = require('../entity/departmentEntity');
        departmentEntity.setDepartmentName(departments.departmentName);
        departmentEntity.setDepartmentCode(departments.departmentCode);
        departmentEntity.setDepartmentId(departments.departmentId);
        const result = await departmentDao.updateDepartmentDao(departmentEntity);
        if (result == 1) {
            return 'S';
        }
        else {
            return 'F';
        }
    }
}

module.exports = {
    insertDepartment,
    fetchDepartmentDetails,
    deleteDepartment,
    updateDepartment
}
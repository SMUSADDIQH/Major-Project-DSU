const placementDao = require('../dao/placementDaoImpl');

async function insertPlacement(placement) {
    if (placement != null) {
        let placementEntity = require('../entity/placementEntity');
        placementEntity.setPlacementName(placement.placementName);
        placementEntity.setContactNumber(placement.contactNumber);
        const result = await placementDao.insertPlacementDao(placementEntity);
        return result;
    }
}

async function fetchPlacemenDetails() {
    return await placementDao.fetchPlacementDao();
}

async function deletePlacement(placementId) {
    return await placementDao.deletePlacementDao(placementId);
}

async function updatePlacement(placement) {
    if (placement != null) {
        let placementEntity = require('../entity/placementEntity');
        placementEntity.setPlacementName(placement.placementName);
        placementEntity.setContactNumber(placement.contactNumber);
        placementEntity.setPlacementId(placement.placementId);
        const result = await placementDao.updatePlacementDao(placementEntity);
        return result;
    }
}

module.exports = {
    insertPlacement,
    fetchPlacemenDetails,
    deletePlacement,
    updatePlacement
}
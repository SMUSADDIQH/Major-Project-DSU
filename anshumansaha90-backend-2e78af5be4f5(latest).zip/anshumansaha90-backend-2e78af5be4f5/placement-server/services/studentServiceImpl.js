const studentDao = require('../dao/studentDaoImpl');

async function insertStudent(students) {
    if (students != null) {
        let studentsEntity = require('../entity/studentEntity');
        studentsEntity.setStudentsName(students.studentName);
        studentsEntity.setDepartmentId(students.departmentId);
        studentsEntity.setMarksheetId(students.marksheetId);
        const result = await studentDao.insertStudentDao(studentsEntity);
        return result;
    }
}

async function fetchStudentsDetails() {
    return await studentDao.fetchStudentsDao();
}

async function deleteStudent(student_id) {
    return await studentDao.deleteStudentDao(student_id);
}

async function updateStudent(students) {
    if (students != null) {
        let studentsEntity = require('../entity/studentEntity');
        studentsEntity.setStudentsName(students.studentName);
        studentsEntity.setDepartmentId(students.departmentId);
        studentsEntity.setStudentId(students.studentId);
        const result = await studentDao.updateStudentDao(studentsEntity);
        return result;
    }
}

async function fetchStudentDetailById(studentId, loginUserId) {
        return await studentDao.fetchStudentbyId(studentId, loginUserId);
}

async function fetchApplicableJobs(studentId, departmentId, marksheetId) {
    return await studentDao.fetchApplicableJobs(studentId, departmentId, marksheetId);
}

async function fetchNonApplicableJobs(studentId, loginUserId) {
    return await studentDao.fetchNonApplicableJobs(studentId, loginUserId);
}

async function applyJob(applyJob) {
    const obj = {
        studentId: applyJob.studentId,
        studentName: applyJob.studentName,
        isApplied: applyJob.isApplied,
        isApproved: applyJob.isApproved
    }
    const result = await studentDao.applyjob(obj, applyJob.jobId);
    if (result == 1) {
        return 'S';
    }
    else {
        return 'F';
    }
}

module.exports = {
    insertStudent,
    fetchStudentsDetails,
    deleteStudent,
    updateStudent,
    fetchStudentDetailById,
    fetchApplicableJobs,
    fetchNonApplicableJobs,
    applyJob
}
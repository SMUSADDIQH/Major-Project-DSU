const jobProfileDao = require('../dao/jobProfileDaoImpl');

async function insertJobProfile(jobprofile) {
    if (jobprofile != null) {
        let jobprofileEntity = require('../entity/jobprofileEntity');
        jobprofileEntity.setCompanyName(jobprofile.companyName);
        jobprofileEntity.setPlacementId(jobprofile.placementId);
        jobprofileEntity.setDepartmentId(jobprofile.departmentId);
        jobprofileEntity.setSemister1(jobprofile.semister1);
        jobprofileEntity.setSemister2(jobprofile.semister2);
        jobprofileEntity.setSemister3(jobprofile.semister3);
        jobprofileEntity.setSemister4(jobprofile.semister4);
        jobprofileEntity.setSemister5(jobprofile.semister5);
        jobprofileEntity.setSemister6(jobprofile.semister6);
        jobprofileEntity.setSemister7(jobprofile.semister7);
        jobprofileEntity.setSemister8(jobprofile.semister8);
        const result = await jobProfileDao.insertjobProfileDao(jobprofileEntity.getObject(jobprofileEntity));
        if (result == 1) {
            return 'S';
        }
        else {
            return 'F';
        }
    }
}

async function fetchjobProfileDetails() {
    return await jobProfileDao.fetchJobprofileDao();
}

async function fetchJobProfileByDepartmentId(departmentId) {
    return await jobProfileDao.fetchJobProfileByDepartmentId(departmentId);
}

async function approveJob(approveJob) {
    const jobId = approveJob.jobId;
    const studentId = approveJob.studentId;
    const jobProfile = await jobProfileDao.fetchJobProfileById(jobId);
    let app_dtl = jobProfile.applicableDetails;
    const index = app_dtl.findIndex(value => value.studentId === studentId);
    let filteredData = app_dtl.filter(data => data.studentId === studentId)[0];
    filteredData.isApproved = true;
    app_dtl[index] = filteredData;
    const resp = await jobProfileDao.updateJobProfileTable(app_dtl, jobId);
    if(resp === 1){
        return 'S';
    }
    return 'E';
}

async function deleteJobProfile(job_id) {
    return await jobProfileDao.deleteJobProfile(job_id);
}

module.exports = {
    insertJobProfile,
    fetchjobProfileDetails,
    approveJob,
    fetchJobProfileByDepartmentId,
    deleteJobProfile
}
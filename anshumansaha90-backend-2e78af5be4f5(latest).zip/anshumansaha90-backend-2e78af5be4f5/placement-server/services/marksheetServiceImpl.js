const marksheetDao = require('../dao/marksheetDaoImpl');

async function insertMarksheet(marksheet) {
    if (marksheet != null) {
        let marksheetEntity = require('../entity/marksheetEntity');
        marksheetEntity.setSemister1(marksheet.semister1);
        marksheetEntity.setSemister2(marksheet.semister2);
        marksheetEntity.setSemister3(marksheet.semister3);
        marksheetEntity.setSemister4(marksheet.semister4);
        marksheetEntity.setSemister5(marksheet.semister5);
        marksheetEntity.setSemister6(marksheet.semister6);
        marksheetEntity.setSemister7(marksheet.semister7);
        marksheetEntity.setSemister8(marksheet.semister8);
        marksheetEntity.setStudentId(marksheet.studentId);
        marksheetEntity.setLoginUserId(marksheet.loginUserId);
        const avg = (marksheetEntity.semister1 + marksheetEntity.semister2 + marksheetEntity.semister3 + marksheetEntity.semister4 + marksheetEntity.semister5 + marksheetEntity.semister6 + marksheetEntity.semister7 + marksheetEntity.semister8) / 8;
        marksheetEntity.setAverage(avg);
        const result = await marksheetDao.insertMarksheetDao(marksheetEntity.getObject(marksheetEntity));
        if (result == 1) {
            return 'S';
        }
        else {
            return 'F';
        }
    }
}

async function fetchMarksheetDetails() {
    return await marksheetDao.fetchMarksheetDao();
}

module.exports = {
    insertMarksheet,
    fetchMarksheetDetails
}
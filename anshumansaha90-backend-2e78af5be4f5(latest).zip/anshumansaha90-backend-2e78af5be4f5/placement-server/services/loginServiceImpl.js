const loginDao = require('../dao/loginDaoImpl');

async function validateLogin(loginProfile) {
    const user_id = loginProfile.user_id;
    const password = loginProfile.password;
    const utype = loginProfile.utype;
    if(user_id != null && password != null && utype != null) {
        const result = await loginDao.validate(user_id, password, utype);
        return result;
    }
}


module.exports = {
    validateLogin
}
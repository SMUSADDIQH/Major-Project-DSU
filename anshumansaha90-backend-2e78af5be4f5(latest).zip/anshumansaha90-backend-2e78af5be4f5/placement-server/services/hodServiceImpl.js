const hodDao = require('../dao/hodDaoImpl');

async function insertHod(hod) {
    if (hod != null) {
        let hodEntity = require('../entity/hodEntity');
        hodEntity.setHodName(hod.hodName);
        hodEntity.setContactNumber(hod.contactNumber);
        hodEntity.setDepartmentId(hod.departmentId);
        const result = await hodDao.insertHodDao(hodEntity);
        return result;
    }
}

async function fetchHodDetails() {
    return await hodDao.fetchHodDao();
}

async function deleteHod(hodId) {
    return await hodDao.deleteHodDao(hodId);
}

async function updateHod(hod) {
    if (hod != null) {
        let hodEntity = require('../entity/hodEntity');
        hodEntity.setHodName(hod.hodName);
        hodEntity.setContactNumber(hod.contactNumber);
        hodEntity.setDepartmentId(hod.departmentId);
        hodEntity.setHodId(hod.hodId);
        const result = await hodDao.updateHodDao(hodEntity);
        return result;
    }
}

async function fetchStudentByHodId(hodId) {
    if (hodId) {
        return await hodDao.fetchStudentByHodId(hodId);
    }
}

async function fetchHodDetailsByHodId(hodId) {
    if (hodId) {
        return await hodDao.fetchHodDetailsByHodId(hodId);
    }
}
module.exports = {
    insertHod,
    fetchHodDetails,
    deleteHod,
    updateHod,
    fetchStudentByHodId,
    fetchHodDetailsByHodId
}
const criteriaDao = require('../dao/criteriaDaoImpl');

async function insertCriteria(criteria) {
    if (criteria != null) {
        let criteriaEntity = require('../entity/criteriaEntity');
        criteriaEntity.setSemister_1(criteria.semister_1);
        criteriaEntity.setSemister_2(criteria.semister_2);
        criteriaEntity.setSemister_3(criteria.semister_3);
        criteriaEntity.setSemister_4(criteria.semister_4);
        criteriaEntity.setSemister_5(criteria.semister_5);
        criteriaEntity.setSemister_6(criteria.semister_6);
        criteriaEntity.setSemister_7(criteria.semister_7);
        criteriaEntity.setSemister_8(criteria.semister_8);
        const avg = (criteriaEntity.semister_1 + criteriaEntity.semister_2 + criteriaEntity.semister_3 + criteriaEntity.semister_4 + criteriaEntity.semister_5 + criteriaEntity.semister_6 + criteriaEntity.semister_7 + criteriaEntity.semister_8) / 8;
        criteriaEntity.setAverage(avg);
        const result = await criteriaDao.insertCriteriaDao(criteriaEntity);
        if (result == 1) {
            return 'S';
        }
        else {
            return 'F';
        }
    }
}

async function fetchCriteriaDetails() {
    return await criteriaDao.fetchCriteriaDao();
}

module.exports = {
    insertCriteria,
    fetchCriteriaDetails
}
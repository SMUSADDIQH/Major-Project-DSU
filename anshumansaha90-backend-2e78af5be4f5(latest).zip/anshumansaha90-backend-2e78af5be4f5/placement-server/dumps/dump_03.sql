-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: campusplacement
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `applicable_vw`
--

DROP TABLE IF EXISTS `applicable_vw`;
/*!50001 DROP VIEW IF EXISTS `applicable_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `applicable_vw` AS SELECT 
 1 AS `job_id`,
 1 AS `comp_nm`,
 1 AS `job_dt`,
 1 AS `stu_id`,
 1 AS `login_user_id`,
 1 AS `app_dtl`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `criteria_tbl`
--

DROP TABLE IF EXISTS `criteria_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `criteria_tbl` (
  `crit_id` int NOT NULL AUTO_INCREMENT,
  `S1` int DEFAULT NULL,
  `S2` int DEFAULT NULL,
  `S3` int DEFAULT NULL,
  `S4` int DEFAULT NULL,
  `S5` int DEFAULT NULL,
  `S6` int DEFAULT NULL,
  `S7` int DEFAULT NULL,
  `S8` int DEFAULT NULL,
  `avg` decimal(2,0) DEFAULT NULL,
  PRIMARY KEY (`crit_id`),
  UNIQUE KEY `crit_id_UNIQUE` (`crit_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `criteria_tbl`
--

LOCK TABLES `criteria_tbl` WRITE;
/*!40000 ALTER TABLE `criteria_tbl` DISABLE KEYS */;
INSERT INTO `criteria_tbl` VALUES (1,7,6,8,9,7,6,7,8,7),(2,70,60,80,90,70,60,70,80,73);
/*!40000 ALTER TABLE `criteria_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `criteria_vw`
--

DROP TABLE IF EXISTS `criteria_vw`;
/*!50001 DROP VIEW IF EXISTS `criteria_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `criteria_vw` AS SELECT 
 1 AS `crit_id`,
 1 AS `S1`,
 1 AS `S2`,
 1 AS `S3`,
 1 AS `S4`,
 1 AS `S5`,
 1 AS `S6`,
 1 AS `S7`,
 1 AS `S8`,
 1 AS `avg`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `department_tbl`
--

DROP TABLE IF EXISTS `department_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `department_tbl` (
  `dept_id` int NOT NULL AUTO_INCREMENT,
  `dept_nm` varchar(45) DEFAULT NULL,
  `dept_cd` varchar(45) DEFAULT NULL,
  `sts` varchar(1) DEFAULT 'A',
  PRIMARY KEY (`dept_id`),
  UNIQUE KEY `dept_id_UNIQUE` (`dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department_tbl`
--

LOCK TABLES `department_tbl` WRITE;
/*!40000 ALTER TABLE `department_tbl` DISABLE KEYS */;
INSERT INTO `department_tbl` VALUES (1,'Transfiguration','TF','A'),(2,'Defence Against the Dark Arts','DADA','A'),(4,'Dark Arts','DA','A'),(5,'Astronomy','AY','A'),(6,'Physics','PH','A'),(7,'Ravenclaw','RW','A'),(8,'Slytherin','SYN','A'),(9,'Hufflepuff','HFF','A'),(10,'Gryffindor','GFF','A'),(11,'Divination','DIVN','A'),(12,'Avengers','AVG','A');
/*!40000 ALTER TABLE `department_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `department_vw`
--

DROP TABLE IF EXISTS `department_vw`;
/*!50001 DROP VIEW IF EXISTS `department_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `department_vw` AS SELECT 
 1 AS `dept_id`,
 1 AS `dept_nm`,
 1 AS `dept_cd`,
 1 AS `sts`,
 1 AS `sts_cd`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `hod_tbl`
--

DROP TABLE IF EXISTS `hod_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hod_tbl` (
  `hod_id` int NOT NULL AUTO_INCREMENT,
  `hod_nm` varchar(45) DEFAULT NULL,
  `cntct_no` varchar(45) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `login_user_id` varchar(45) DEFAULT NULL,
  `sts` varchar(1) DEFAULT 'A',
  PRIMARY KEY (`hod_id`),
  UNIQUE KEY `hod_id_UNIQUE` (`hod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hod_tbl`
--

LOCK TABLES `hod_tbl` WRITE;
/*!40000 ALTER TABLE `hod_tbl` DISABLE KEYS */;
INSERT INTO `hod_tbl` VALUES (1,'Albus Dumbledore','1256325489',5,'Albus Dumbledore_6','A'),(2,'Alastor Moody','1234567890',2,'Alastor Moody_2','A'),(3,'Aurora Sinistra','1452369870',6,'Aurora Sinistra_3','A'),(4,'Charity Burbage','1452369870',12,'Charity Burbage_4','A'),(5,'Firenze','1456985236',11,'Firenze_5','A');
/*!40000 ALTER TABLE `hod_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `hod_vw`
--

DROP TABLE IF EXISTS `hod_vw`;
/*!50001 DROP VIEW IF EXISTS `hod_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `hod_vw` AS SELECT 
 1 AS `hod_id`,
 1 AS `hod_nm`,
 1 AS `cntct_no`,
 1 AS `dept_nm`,
 1 AS `dept_id`,
 1 AS `sts`,
 1 AS `sts_cd`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `job_vw`
--

DROP TABLE IF EXISTS `job_vw`;
/*!50001 DROP VIEW IF EXISTS `job_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `job_vw` AS SELECT 
 1 AS `job_id`,
 1 AS `comp_nm`,
 1 AS `job_dt`,
 1 AS `dept_nm`,
 1 AS `dept_cd`,
 1 AS `plcmt_nm`,
 1 AS `plcmt_cntct_no`,
 1 AS `S1`,
 1 AS `S2`,
 1 AS `S3`,
 1 AS `S4`,
 1 AS `S5`,
 1 AS `S6`,
 1 AS `S7`,
 1 AS `S8`,
 1 AS `avg`,
 1 AS `app_dtl`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `jobprofile_tbl`
--

DROP TABLE IF EXISTS `jobprofile_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobprofile_tbl` (
  `job_id` int NOT NULL AUTO_INCREMENT,
  `comp_nm` varchar(45) DEFAULT NULL,
  `crit_id` varchar(45) DEFAULT NULL,
  `job_dt` varchar(45) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `plcmt_id` int DEFAULT NULL,
  `app_dtl` json DEFAULT NULL,
  PRIMARY KEY (`job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobprofile_tbl`
--

LOCK TABLES `jobprofile_tbl` WRITE;
/*!40000 ALTER TABLE `jobprofile_tbl` DISABLE KEYS */;
INSERT INTO `jobprofile_tbl` VALUES (1,'wipro','2','2022-05-16',6,1,'[{\"isApplied\": true, \"studentId\": 19, \"isApproved\": true, \"studentName\": \"Doctor Strange\"}, {\"isApplied\": true, \"studentId\": 20, \"isApproved\": false, \"studentName\": \"Doctor Strange\"}]'),(2,'infosys','2','2022-05-16',6,1,'[{\"isApplied\": true, \"studentId\": 19, \"isApproved\": true, \"studentName\": \"Doctor Strange\"}]');
/*!40000 ALTER TABLE `jobprofile_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_tbl`
--

DROP TABLE IF EXISTS `login_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_tbl` (
  `login_id` int NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) DEFAULT NULL,
  `pwd` varchar(45) DEFAULT NULL,
  `utype` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`login_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_tbl`
--

LOCK TABLES `login_tbl` WRITE;
/*!40000 ALTER TABLE `login_tbl` DISABLE KEYS */;
INSERT INTO `login_tbl` VALUES (1,'student','123456','student'),(2,'hod','123456','hod'),(3,'placement','123456','placement'),(4,'admin','admin','admin'),(5,'sdas_0','11de7720c93752b9f11563ff43be7f5d','student'),(6,'asdasd_4','e825b86931ae258985579c1fdc4027d5','student'),(7,'asdasd_5','976a14d72623408fb06b0fa780e3b3b6','student'),(8,'Nataraj_6','fcdd9c8a185b81756f387ca8404ffa05','student'),(9,'Racheal_2','a11ae0fb6a415926273b593cc80c9622','student'),(12,'Harry Potter_1','1adaf33e579e03bf48cb33f4404b3179','student'),(13,'Hermione_1','8c2a0d7ca7d3a569649b8d580e8b2309','student'),(14,'Alastor Moody_2','5b345bead96af7ab84a96cb5cd442ad5','hod'),(15,'Aurora Sinistra_3','d73a0abd035bb0f2e8fd7e0787c028dc','hod'),(16,'Charity Burbage_4','0b17ced89bddc7c8fe56d8fa3d38e01c','hod'),(17,'Firenze_5','131b97ba6edb47d0ff1fda601601ba29','hod'),(18,'Ron_2','68c4554e549b1b2e8e274d5c4f52fc9c','student'),(19,'Lucius Malfoy_1','876fdb02cd46dbfa1a46d66d3613a8eb','student'),(20,'Doctor Strange_1','47ecfb982326d5f91814b33e21ee3997','student'),(21,'samsung_2','0f8bedcea411a0ae5b566a372521ac17','student'),(31,'jackfruit_1','423086662cc22630db449527cb66c48c','student'),(35,'Albus Dumbledore_6','c897a2322574a8b947ff2087222eed4b','hod'),(38,'Charity Burbage_1','4f4fd146944b31cf89ea1053c6e4de9a','placement'),(45,'samsungs_3','645dc5453e140d4d76c9d181bbcf26e8','student'),(48,'test_1','bad0a539cf3de0839ad5a9a3a2760e93','student');
/*!40000 ALTER TABLE `login_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `login_vw`
--

DROP TABLE IF EXISTS `login_vw`;
/*!50001 DROP VIEW IF EXISTS `login_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `login_vw` AS SELECT 
 1 AS `login_id`,
 1 AS `login_user_id`,
 1 AS `pwd`,
 1 AS `utype`,
 1 AS `user_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `marksheet_tbl`
--

DROP TABLE IF EXISTS `marksheet_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `marksheet_tbl` (
  `mrksht_id` int NOT NULL AUTO_INCREMENT,
  `S1` int DEFAULT NULL,
  `S2` int DEFAULT NULL,
  `S3` int DEFAULT NULL,
  `S4` int DEFAULT NULL,
  `S5` int DEFAULT NULL,
  `S6` int DEFAULT NULL,
  `S7` int DEFAULT NULL,
  `S8` int DEFAULT NULL,
  `avg` double DEFAULT NULL,
  PRIMARY KEY (`mrksht_id`),
  UNIQUE KEY `mrksht_id_UNIQUE` (`mrksht_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marksheet_tbl`
--

LOCK TABLES `marksheet_tbl` WRITE;
/*!40000 ALTER TABLE `marksheet_tbl` DISABLE KEYS */;
INSERT INTO `marksheet_tbl` VALUES (1,60,60,60,60,60,60,60,60,60),(2,90,90,90,90,90,90,90,90,90);
/*!40000 ALTER TABLE `marksheet_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `marksheet_vw`
--

DROP TABLE IF EXISTS `marksheet_vw`;
/*!50001 DROP VIEW IF EXISTS `marksheet_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `marksheet_vw` AS SELECT 
 1 AS `mrksht_id`,
 1 AS `S1`,
 1 AS `S2`,
 1 AS `S3`,
 1 AS `S4`,
 1 AS `S5`,
 1 AS `S6`,
 1 AS `S7`,
 1 AS `S8`,
 1 AS `avg`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `non_applicable_vw`
--

DROP TABLE IF EXISTS `non_applicable_vw`;
/*!50001 DROP VIEW IF EXISTS `non_applicable_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `non_applicable_vw` AS SELECT 
 1 AS `job_id`,
 1 AS `comp_nm`,
 1 AS `job_dt`,
 1 AS `stu_id`,
 1 AS `login_user_id`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `placement_tbl`
--

DROP TABLE IF EXISTS `placement_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `placement_tbl` (
  `plcmt_id` int NOT NULL AUTO_INCREMENT,
  `plcmt_nm` varchar(45) DEFAULT NULL,
  `cntct_no` varchar(45) DEFAULT NULL,
  `login_user_id` varchar(45) DEFAULT NULL,
  `sts` varchar(1) DEFAULT 'A',
  PRIMARY KEY (`plcmt_id`),
  UNIQUE KEY `plcmt_id_UNIQUE` (`plcmt_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `placement_tbl`
--

LOCK TABLES `placement_tbl` WRITE;
/*!40000 ALTER TABLE `placement_tbl` DISABLE KEYS */;
INSERT INTO `placement_tbl` VALUES (1,'Charity Burbage','963258741','Charity Burbage_1','A');
/*!40000 ALTER TABLE `placement_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `placement_vw`
--

DROP TABLE IF EXISTS `placement_vw`;
/*!50001 DROP VIEW IF EXISTS `placement_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `placement_vw` AS SELECT 
 1 AS `plcmt_id`,
 1 AS `plcmt_nm`,
 1 AS `cntct_no`,
 1 AS `sts`,
 1 AS `sts_cd`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `student_tbl`
--

DROP TABLE IF EXISTS `student_tbl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_tbl` (
  `stu_id` int NOT NULL AUTO_INCREMENT,
  `stu_nm` varchar(45) DEFAULT NULL,
  `dept_id` int DEFAULT NULL,
  `mrksht_id` int DEFAULT NULL,
  `login_user_id` varchar(45) DEFAULT NULL,
  `sts` varchar(1) DEFAULT 'A',
  PRIMARY KEY (`stu_id`),
  UNIQUE KEY `stu_id_UNIQUE` (`stu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_tbl`
--

LOCK TABLES `student_tbl` WRITE;
/*!40000 ALTER TABLE `student_tbl` DISABLE KEYS */;
INSERT INTO `student_tbl` VALUES (19,'Doctor Strange',12,2,'Doctor Strange_1','A'),(20,'samsung',5,NULL,'samsung_2','A'),(23,'jackfruit',2,NULL,'jackfruit_1','A'),(26,'samsungs',5,NULL,'samsungs_3','A'),(27,'test',11,NULL,'test_1','A');
/*!40000 ALTER TABLE `student_tbl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `student_vw`
--

DROP TABLE IF EXISTS `student_vw`;
/*!50001 DROP VIEW IF EXISTS `student_vw`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `student_vw` AS SELECT 
 1 AS `stu_id`,
 1 AS `stu_nm`,
 1 AS `dept_nm`,
 1 AS `dept_cd`,
 1 AS `dept_id`,
 1 AS `hod_id`,
 1 AS `S1`,
 1 AS `S2`,
 1 AS `S3`,
 1 AS `S4`,
 1 AS `S5`,
 1 AS `S6`,
 1 AS `S7`,
 1 AS `S8`,
 1 AS `avg`,
 1 AS `login_user_id`,
 1 AS `sts`,
 1 AS `sts_cd`*/;
SET character_set_client = @saved_cs_client;

--
-- Dumping events for database 'campusplacement'
--

--
-- Dumping routines for database 'campusplacement'
--
/*!50003 DROP PROCEDURE IF EXISTS `sp_hod_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_hod_add`(in p_hod_nm varchar(50), in p_dept_id int, in p_cntct_no varchar(45), out p_hod_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_count int default 0;
declare v_hod_login_id varchar(50);
declare v_pwd varchar(50);

select count(*) into v_count from hod_tbl;

set v_hod_login_id =concat(p_hod_nm,'_',v_count+1);
SELECT MD5(RAND()) into v_pwd;

insert into hod_tbl(hod_nm, cntct_no, dept_id, login_user_id) values(p_hod_nm, p_cntct_no, p_dept_id, v_hod_login_id);

insert into login_tbl(user_id,pwd,utype) values(v_hod_login_id, v_pwd, 'hod');

set p_hod_id = v_hod_login_id;
set p_pwd = v_pwd;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_hod_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_hod_delete`(in p_hod_id varchar(50))
BEGIN
declare v_login_user_id	varchar(50);

select login_user_id into v_login_user_id from hod_tbl where hod_id = p_hod_id;

delete from login_tbl where user_id = v_login_user_id and utype = 'hod';

delete from hod_tbl where hod_id = p_hod_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_hod_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_hod_update`(in p_hod_id int, in p_hod_nm varchar(50), in p_dept_id int, in p_cntct_no varchar(45), out p_nw_hod_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_login_user_id varchar(50);
declare v_count int default 0;
declare v_hod_login_id varchar(50);
declare v_pwd varchar(50);

if p_hod_id is not null then
select count(*) into v_count from hod_tbl where hod_id <> p_hod_id;
select login_user_id into v_login_user_id from hod_tbl where hod_id = p_hod_id;
set v_hod_login_id =concat(p_hod_nm,'_',v_count+1);
SELECT MD5(RAND()) into v_pwd;

delete from login_tbl where user_id = v_login_user_id and utype = 'hod';
insert into login_tbl(user_id,pwd,utype) values(v_hod_login_id, v_pwd, 'hod');
update hod_tbl set hod_nm = p_hod_nm, cntct_no = p_cntct_no, dept_id = p_dept_id, login_user_id = v_hod_login_id where hod_id = p_hod_id;


set p_nw_hod_id = v_hod_login_id;
set p_pwd = v_pwd;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_job_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_job_add`(in p_job_dtl JSON)
BEGIN
declare v_crit_id	INT;
declare v_comp_nm	VARCHAR(100);
declare v_job_dt	DATE;
declare v_dept_id	int;
declare v_plcmt_id	int;
declare	v_s1	int;
declare	v_s2	int;
declare	v_s3	int;
declare v_s4	int;
declare v_s5	int;
declare	v_s6	int;
declare	v_s7	int;
declare v_s8	int;
declare v_avg	DOUBLE;
declare v_count_crit	int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
START TRANSACTION;

if p_job_dtl is not null then
set v_s1 = JSON_EXTRACT(p_job_dtl, '$.semister1');
set v_s2 = JSON_EXTRACT(p_job_dtl, '$.semister2');
set v_s3 = JSON_EXTRACT(p_job_dtl, '$.semister3');
set v_s4 = JSON_EXTRACT(p_job_dtl, '$.semister4');
set v_s5 = JSON_EXTRACT(p_job_dtl, '$.semister5');
set v_s6 = JSON_EXTRACT(p_job_dtl, '$.semister6');
set v_s7 = JSON_EXTRACT(p_job_dtl, '$.semister7');
set v_s8 = JSON_EXTRACT(p_job_dtl, '$.semister8');
set v_comp_nm = JSON_UNQUOTE(JSON_EXTRACT(p_job_dtl, '$.companyName'));
set v_dept_id = JSON_EXTRACT(p_job_dtl, '$.departmentId');
set v_plcmt_id = JSON_EXTRACT(p_job_dtl, '$.placementId');

select count(crit_id) into v_count_crit from criteria_tbl 
where 
s1 = v_s1 and
s2 = v_s2 and
s3 = v_s3 and
s4 = v_s4 and
s5 = v_s5 and
s6 = v_s6 and
s7 = v_s7 and
s8 = v_s8;
if v_count_crit > 0 then
select crit_id into v_crit_id from criteria_tbl
where
s1 = v_s1 and
s2 = v_s2 and
s3 = v_s3 and
s4 = v_s4 and
s5 = v_s5 and
s6 = v_s6 and
s7 = v_s7 and
s8 = v_s8;
else
set v_avg = (v_s1+v_s2+v_s3+v_s4+v_s5+v_s6+v_s7+v_s8)/8;
insert into criteria_tbl(S1,S2,S3,S4,S5,S6,S7,S8,`avg`) values (v_s1, v_s2, v_s3, v_s4, v_s5, v_s6, v_s7, v_s8, v_avg);
SELECT LAST_INSERT_ID() into v_crit_id;
end if;
select curdate() into v_job_dt;
insert into jobprofile_tbl(comp_nm, crit_id, job_dt, dept_id, plcmt_id)
values(v_comp_nm, v_crit_id, v_job_dt, v_dept_id, v_plcmt_id);
COMMIT;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_job_apply` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_job_apply`(in p_job_dtl json, in p_job_id int)
BEGIN
declare v_app_dtl	json;
declare v_stu_id	int;
declare v_isApplied	BOOLEAN;
declare v_isApproved	BOOLEAN;
declare v_app_dtl_nw	json;
if p_job_dtl is not null then 
set v_stu_id = JSON_EXTRACT(p_job_dtl, '$.studentId');
set v_isApplied = JSON_EXTRACT(p_job_dtl, '$.isApplied');
set v_isApproved = JSON_EXTRACT(p_job_dtl, '$.isApproved');

select app_dtl into v_app_dtl from jobprofile_tbl where job_id = p_job_id;

if v_app_dtl is null then 
update jobprofile_tbl set app_dtl = JSON_ARRAY(p_job_dtl) where job_id = p_job_id;
else
set v_app_dtl_nw = JSON_ARRAY_APPEND(v_app_dtl,'$', p_job_dtl);
update jobprofile_tbl set app_dtl = v_app_dtl_nw where job_id = p_job_id;

end if;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_marksheet_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_marksheet_add`(in p_mrksht_dtl JSON)
BEGIN
declare v_mrksht_id	INT;
declare	v_s1	int;
declare	v_s2	int;
declare	v_s3	int;
declare v_s4	int;
declare v_s5	int;
declare	v_s6	int;
declare	v_s7	int;
declare v_s8	int;
declare v_avg	DOUBLE;
declare v_stu_id	int;
declare	v_login_user_id	varchar(100);
declare v_count_mrksht	int;
DECLARE EXIT HANDLER FOR SQLEXCEPTION 
    BEGIN
        ROLLBACK;
    END;
START TRANSACTION;

if p_mrksht_dtl is not null then
set	v_stu_id = JSON_EXTRACT(p_mrksht_dtl, '$.studentId');
set	v_login_user_id = JSON_UNQUOTE(JSON_EXTRACT(p_mrksht_dtl, '$.loginUserId'));
set v_s1 = JSON_EXTRACT(p_mrksht_dtl, '$.semister1');
set v_s2 = JSON_EXTRACT(p_mrksht_dtl, '$.semister2');
set v_s3 = JSON_EXTRACT(p_mrksht_dtl, '$.semister3');
set v_s4 = JSON_EXTRACT(p_mrksht_dtl, '$.semister4');
set v_s5 = JSON_EXTRACT(p_mrksht_dtl, '$.semister5');
set v_s6 = JSON_EXTRACT(p_mrksht_dtl, '$.semister6');
set v_s7 = JSON_EXTRACT(p_mrksht_dtl, '$.semister7');
set v_s8 = JSON_EXTRACT(p_mrksht_dtl, '$.semister8');

select count(mrksht_id) into v_count_mrksht from marksheet_tbl 
where 
s1 = v_s1 and
s2 = v_s2 and
s3 = v_s3 and
s4 = v_s4 and
s5 = v_s5 and
s6 = v_s6 and
s7 = v_s7 and
s8 = v_s8;
if v_count_mrksht > 0 then
select mrksht_id into v_mrksht_id from marksheet_tbl
where
s1 = v_s1 and
s2 = v_s2 and
s3 = v_s3 and
s4 = v_s4 and
s5 = v_s5 and
s6 = v_s6 and
s7 = v_s7 and
s8 = v_s8;
else
set v_avg = (v_s1+v_s2+v_s3+v_s4+v_s5+v_s6+v_s7+v_s8)/8;
insert into marksheet_tbl(S1,S2,S3,S4,S5,S6,S7,S8,`avg`) values (v_s1, v_s2, v_s3, v_s4, v_s5, v_s6, v_s7, v_s8, v_avg);
SELECT LAST_INSERT_ID() into v_mrksht_id;
end if;
#select concat(v_mrksht_id,"---",v_stu_id,"---",v_login_user_id);
UPDATE student_tbl SET mrksht_id = v_mrksht_id where stu_id = v_stu_id and login_user_id = v_login_user_id;
COMMIT;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_placement_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_placement_add`(in p_placement_nm varchar(50),  in p_cntct_no varchar(45), out p_placement_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_count int default 0;
declare v_placement_id varchar(50);
declare v_pwd varchar(50);

select count(*) into v_count from placement_tbl;

set v_placement_id =concat(p_placement_nm,'_',v_count+1);
SELECT MD5(RAND()) into v_pwd;

insert into placement_tbl(plcmt_nm, cntct_no, login_user_id) values(p_placement_nm, p_cntct_no, v_placement_id);

insert into login_tbl(user_id,pwd,utype) values(v_placement_id, v_pwd, 'placement');

set p_placement_id = v_placement_id;
set p_pwd = v_pwd;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_placement_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_placement_delete`(in p_placement_id varchar(50))
BEGIN
declare v_login_user_id	varchar(50);

select login_user_id into v_login_user_id from placement_tbl where plcmt_id = p_placement_id;

delete from login_tbl where user_id = v_login_user_id and utype = 'placement';

delete from placement_tbl where plcmt_id = p_placement_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_placement_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_placement_update`(in p_placement_id int, in p_placement_nm varchar(50),  in p_cntct_no varchar(45), out p_nw_placement_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_login_user_id varchar(50);
declare v_count int default 0;
declare v_placement_login_id varchar(50);
declare v_pwd varchar(50);

if p_placement_id is not null then
select count(*) into v_count from placement_tbl where plcmt_id <> p_placement_id;
select login_user_id into v_login_user_id from placement_tbl where plcmt_id = p_placement_id;
set v_placement_login_id =concat(p_placement_nm,'_',v_count+1);
SELECT MD5(RAND()) into v_pwd;

delete from login_tbl where user_id = v_login_user_id and utype = 'placement';
insert into login_tbl(user_id,pwd,utype) values(v_placement_login_id, v_pwd, 'placement');
update placement_tbl set plcmt_nm = p_placement_nm, cntct_no = p_cntct_no, login_user_id = v_placement_login_id where plcmt_id = p_placement_id;

set p_nw_placement_id = v_placement_login_id;
set p_pwd = v_pwd;

end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_students_add` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_students_add`(in p_stu_nm varchar(50), in p_dept_id int, out p_stu_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_count int default 0;
declare v_stu_id varchar(50);
declare v_pwd varchar(50);

select count(*) into v_count from student_tbl where dept_id = p_dept_id;

set v_stu_id =concat(p_stu_nm,'_',v_count+1);

SELECT MD5(RAND()) into v_pwd;

insert into student_tbl(stu_nm,dept_id, login_user_id) values(p_stu_nm,p_dept_id, v_stu_id);

insert into login_tbl(user_id,pwd,utype) values(v_stu_id, v_pwd, 'student');

set p_stu_id = v_stu_id;
set p_pwd = v_pwd;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_students_delete` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_students_delete`(in p_student_id varchar(50))
BEGIN
declare v_login_user_id	varchar(50);

select login_user_id into v_login_user_id from student_tbl where stu_id = p_student_id;

delete from login_tbl where user_id = v_login_user_id and utype = 'student';

delete from student_tbl where stu_id = p_student_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `sp_students_update` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_students_update`(in p_stu_id varchar(50), in p_student_nm varchar(50), in p_dept_id int, out p_nw_stu_id varchar(50), out p_pwd varchar(50))
BEGIN
declare v_login_user_id varchar(50);
declare v_pwd varchar(50);
declare v_count int default 0;
declare v_stu_login_id varchar(50);
if p_stu_id is not null then
select count(*) into v_count from student_tbl where dept_id = p_dept_id and stu_id <> p_stu_id;
select login_user_id into v_login_user_id from student_tbl where stu_id = p_stu_id;
set v_stu_login_id =concat(p_student_nm,'_',v_count+1);
SELECT MD5(RAND()) into v_pwd;

delete from login_tbl where user_id = v_login_user_id and utype = 'student';
insert into login_tbl(user_id,pwd,utype) values(v_stu_login_id, v_pwd, 'student');
update student_tbl set stu_nm = p_student_nm, dept_id = p_dept_id, login_user_id = v_stu_login_id where stu_id = p_stu_id;


set p_nw_stu_id = v_stu_login_id;
set p_pwd = v_pwd;
end if;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `applicable_vw`
--

/*!50001 DROP VIEW IF EXISTS `applicable_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `applicable_vw` AS select `jtbl`.`job_id` AS `job_id`,`jtbl`.`comp_nm` AS `comp_nm`,`jtbl`.`job_dt` AS `job_dt`,`stbl`.`stu_id` AS `stu_id`,`stbl`.`login_user_id` AS `login_user_id`,`jtbl`.`app_dtl` AS `app_dtl` from (((`jobprofile_tbl` `jtbl` join `criteria_tbl` `ctbl`) join `student_tbl` `stbl`) join `marksheet_tbl` `mtbl`) where ((`jtbl`.`crit_id` = `ctbl`.`crit_id`) and (`stbl`.`mrksht_id` = `mtbl`.`mrksht_id`) and (`mtbl`.`avg` >= `ctbl`.`avg`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `criteria_vw`
--

/*!50001 DROP VIEW IF EXISTS `criteria_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `criteria_vw` AS select `criteria_tbl`.`crit_id` AS `crit_id`,`criteria_tbl`.`S1` AS `S1`,`criteria_tbl`.`S2` AS `S2`,`criteria_tbl`.`S3` AS `S3`,`criteria_tbl`.`S4` AS `S4`,`criteria_tbl`.`S5` AS `S5`,`criteria_tbl`.`S6` AS `S6`,`criteria_tbl`.`S7` AS `S7`,`criteria_tbl`.`S8` AS `S8`,`criteria_tbl`.`avg` AS `avg` from `criteria_tbl` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `department_vw`
--

/*!50001 DROP VIEW IF EXISTS `department_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `department_vw` AS select `dtbl`.`dept_id` AS `dept_id`,`dtbl`.`dept_nm` AS `dept_nm`,`dtbl`.`dept_cd` AS `dept_cd`,(case when (`dtbl`.`sts` = 'A') then 'Active' else 'Inactive' end) AS `sts`,`dtbl`.`sts` AS `sts_cd` from `department_tbl` `dtbl` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hod_vw`
--

/*!50001 DROP VIEW IF EXISTS `hod_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hod_vw` AS select `htbl`.`hod_id` AS `hod_id`,`htbl`.`hod_nm` AS `hod_nm`,`htbl`.`cntct_no` AS `cntct_no`,`dtbl`.`dept_nm` AS `dept_nm`,`dtbl`.`dept_id` AS `dept_id`,(case when (`htbl`.`sts` = 'A') then 'Active' else 'Inactive' end) AS `sts`,`htbl`.`sts` AS `sts_cd` from (`hod_tbl` `htbl` left join `department_tbl` `dtbl` on(((`htbl`.`dept_id` = `dtbl`.`dept_id`) and (`dtbl`.`sts` = 'A')))) where (`htbl`.`sts` = 'A') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `job_vw`
--

/*!50001 DROP VIEW IF EXISTS `job_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `job_vw` AS select `jtbl`.`job_id` AS `job_id`,`jtbl`.`comp_nm` AS `comp_nm`,`jtbl`.`job_dt` AS `job_dt`,`dtbl`.`dept_nm` AS `dept_nm`,`dtbl`.`dept_cd` AS `dept_cd`,`ptbl`.`plcmt_nm` AS `plcmt_nm`,`ptbl`.`cntct_no` AS `plcmt_cntct_no`,`ctbl`.`S1` AS `S1`,`ctbl`.`S2` AS `S2`,`ctbl`.`S3` AS `S3`,`ctbl`.`S4` AS `S4`,`ctbl`.`S5` AS `S5`,`ctbl`.`S6` AS `S6`,`ctbl`.`S7` AS `S7`,`ctbl`.`S8` AS `S8`,`ctbl`.`avg` AS `avg`,`jtbl`.`app_dtl` AS `app_dtl` from (((`jobprofile_tbl` `jtbl` join `department_tbl` `dtbl` on(((`jtbl`.`dept_id` = `dtbl`.`dept_id`) and (`dtbl`.`sts` = 'A')))) left join `criteria_tbl` `ctbl` on((`jtbl`.`crit_id` = `ctbl`.`crit_id`))) left join `placement_tbl` `ptbl` on((`jtbl`.`plcmt_id` = `ptbl`.`plcmt_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `login_vw`
--

/*!50001 DROP VIEW IF EXISTS `login_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `login_vw` AS select `ltbl`.`login_id` AS `login_id`,`ltbl`.`user_id` AS `login_user_id`,`ltbl`.`pwd` AS `pwd`,`ltbl`.`utype` AS `utype`,(case when (`ltbl`.`utype` = 'student') then `stbl`.`stu_id` when (`ltbl`.`utype` = 'hod') then `htbl`.`hod_id` when (`ltbl`.`utype` = 'placement') then `ptbl`.`plcmt_id` else NULL end) AS `user_id` from (((`login_tbl` `ltbl` left join `student_tbl` `stbl` on((`ltbl`.`user_id` = `stbl`.`login_user_id`))) left join `hod_tbl` `htbl` on((`ltbl`.`user_id` = `htbl`.`login_user_id`))) left join `placement_tbl` `ptbl` on((`ltbl`.`user_id` = `ptbl`.`login_user_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `marksheet_vw`
--

/*!50001 DROP VIEW IF EXISTS `marksheet_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `marksheet_vw` AS select `marksheet_tbl`.`mrksht_id` AS `mrksht_id`,`marksheet_tbl`.`S1` AS `S1`,`marksheet_tbl`.`S2` AS `S2`,`marksheet_tbl`.`S3` AS `S3`,`marksheet_tbl`.`S4` AS `S4`,`marksheet_tbl`.`S5` AS `S5`,`marksheet_tbl`.`S6` AS `S6`,`marksheet_tbl`.`S7` AS `S7`,`marksheet_tbl`.`S8` AS `S8`,`marksheet_tbl`.`avg` AS `avg` from `marksheet_tbl` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `non_applicable_vw`
--

/*!50001 DROP VIEW IF EXISTS `non_applicable_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `non_applicable_vw` AS select `jtbl`.`job_id` AS `job_id`,`jtbl`.`comp_nm` AS `comp_nm`,`jtbl`.`job_dt` AS `job_dt`,`stbl`.`stu_id` AS `stu_id`,`stbl`.`login_user_id` AS `login_user_id` from (((`jobprofile_tbl` `jtbl` join `criteria_tbl` `ctbl`) join `student_tbl` `stbl`) join `marksheet_tbl` `mtbl`) where ((`jtbl`.`crit_id` = `ctbl`.`crit_id`) and (`stbl`.`mrksht_id` = `mtbl`.`mrksht_id`) and (`mtbl`.`avg` < `ctbl`.`avg`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `placement_vw`
--

/*!50001 DROP VIEW IF EXISTS `placement_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `placement_vw` AS select `placement_tbl`.`plcmt_id` AS `plcmt_id`,`placement_tbl`.`plcmt_nm` AS `plcmt_nm`,`placement_tbl`.`cntct_no` AS `cntct_no`,(case when (`placement_tbl`.`sts` = 'A') then 'Active' else 'Inactive' end) AS `sts`,`placement_tbl`.`sts` AS `sts_cd` from `placement_tbl` where (`placement_tbl`.`sts` = 'A') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `student_vw`
--

/*!50001 DROP VIEW IF EXISTS `student_vw`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `student_vw` AS select `stbl`.`stu_id` AS `stu_id`,`stbl`.`stu_nm` AS `stu_nm`,`dtbl`.`dept_nm` AS `dept_nm`,`dtbl`.`dept_cd` AS `dept_cd`,`dtbl`.`dept_id` AS `dept_id`,`hdvw`.`hod_id` AS `hod_id`,`mtbl`.`S1` AS `S1`,`mtbl`.`S2` AS `S2`,`mtbl`.`S3` AS `S3`,`mtbl`.`S4` AS `S4`,`mtbl`.`S5` AS `S5`,`mtbl`.`S6` AS `S6`,`mtbl`.`S7` AS `S7`,`mtbl`.`S8` AS `S8`,`mtbl`.`avg` AS `avg`,`stbl`.`login_user_id` AS `login_user_id`,(case when (`stbl`.`sts` = 'A') then 'Active' else 'Inactive' end) AS `sts`,`stbl`.`sts` AS `sts_cd` from (((`student_tbl` `stbl` join `department_tbl` `dtbl` on(((`stbl`.`dept_id` = `dtbl`.`dept_id`) and (`dtbl`.`sts` = 'A')))) left join `marksheet_tbl` `mtbl` on((`stbl`.`mrksht_id` = `mtbl`.`mrksht_id`))) join `hod_vw` `hdvw` on((`hdvw`.`dept_id` = `stbl`.`dept_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-17 14:21:06

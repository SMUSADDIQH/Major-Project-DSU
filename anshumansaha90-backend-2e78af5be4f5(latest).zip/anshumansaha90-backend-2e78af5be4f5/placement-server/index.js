const express = require('express');
const app = express();
const fs = require('fs');
const cors = require('cors');
const studentService = require('./services/studentServiceImpl');
const criteriaService = require('./services/criteriaServiceImpl');
const hodService = require('./services/hodServiceImpl');
const jobprofileService = require('./services/jobprofileServiceImpl');
const marksheetService = require('./services/marksheetServiceImpl');
const departmentService = require('./services/departmentServiceImpl');
const placementService = require('./services/placementServiceImpl');
const loginService = require('./services/loginServiceImpl');

app.use(express.json(), cors());


//* ###################################-----GET API-----###################################
app.get('/listStudents', async function (req, res) {
   console.log('REST end point: listStudents');
   const data = await studentService.fetchStudentsDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/getStudentDetailByHodId/:id', async function (req, res) {
   const hodId = req.params['id'];
   if (hodId) {
      const data = await hodService.fetchStudentByHodId(hodId);
      if (data) {
         const dataString = JSON.stringify(data);
         res.statusCode = 200;
         res.end(dataString);
      }
      else {
         res.statusCode = 204;
         res.end('No Content');
      }
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/getHodDetailsByHodId/:id', async function (req, res) {
   const hodId = req.params['id'];
   if (hodId) {
      const data = await hodService.fetchHodDetailsByHodId(hodId);
      if (data) {
         const dataString = JSON.stringify(data);
         res.statusCode = 200;
         res.end(dataString);
      }
      else {
         res.statusCode = 204;
         res.end('No Content');
      }
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/getStudentDetailById/:id/:loginUserId', async function (req, res) {
   const student_id = req.params['id'];
   const loginUserId = req.params['loginUserId'];
   if (student_id && loginUserId) {
      const data = await studentService.fetchStudentDetailById(student_id, loginUserId);
      if (data) {
         const dataString = JSON.stringify(data);
         res.statusCode = 200;
         res.end(dataString);
      }
      else {
         res.statusCode = 204;
         res.end('No Content');
      }
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listJobprofile', async function (req, res) {
   const data = await jobprofileService.fetchjobProfileDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listJobprofileByDepartmentId/:departmentId', async function (req, res) {
   const departmentId = req.params['departmentId'];
   const data = await jobprofileService.fetchJobProfileByDepartmentId(departmentId);
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listCriteria', async function (req, res) {
   const data = await criteriaService.fetchCriteriaDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listHod', async function (req, res) {
   const data = await hodService.fetchHodDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listPlacement', async function (req, res) {
   const data = await placementService.fetchPlacemenDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listMarksheet', async function (req, res) {
   const data = await marksheetService.fetchMarksheetDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listDepartment', async function (req, res) {
   const data = await departmentService.fetchDepartmentDetails();
   if (data) {
      const dataString = JSON.stringify(data);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listApplicableJobs/:id/:departmentId/:marksheetId', async function (req, res) {
   const student_id = req.params['id'];
   const departmentId = req.params['departmentId'];
   const marksheetId = req.params['marksheetId'];
   if (student_id && departmentId && marksheetId) {
      const data = await studentService.fetchApplicableJobs(student_id, departmentId, marksheetId);
      if (data && data.length > 0) {
         const dataString = JSON.stringify(data);
         res.statusCode = 200;
         res.end(dataString);
      }
      else {
         res.statusCode = 204;
         res.end('No Content');
      }
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.get('/listNonApplicableJobs/:id/:loginUserId', async function (req, res) {
   const student_id = req.params['id'];
   const loginUserId = req.params['loginUserId'];
   if (student_id && loginUserId) {
      const data = await studentService.fetchNonApplicableJobs(student_id, loginUserId);
      if (data && data.length > 0) {
         const dataString = JSON.stringify(data);
         res.statusCode = 200;
         res.end(dataString);
      }
      else {
         res.statusCode = 204;
         res.end('No Content');
      }
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

//* ###################################-----POST API-----###################################

app.post('/login', async function (req, res) {
   const login = req.body.login;
   const result = await loginService.validateLogin(login);
   if (result) {
      const dataString = JSON.stringify(result);
      res.statusCode = 200;
      res.end(dataString);
   }
   else {
      res.statusCode = 500;
      res.end('ERROR');
   }
});

app.post('/insertStudent', async function (req, res) {
   const students = req.body.students;
   const result = await studentService.insertStudent(students);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertDepartment', async function (req, res) {
   const departments = req.body.departments;
   const result = await departmentService.insertDepartment(departments);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertCriteria', async function (req, res) {
   const criteria = req.body.criteria;
   const result = await criteriaService.insertCriteria(criteria);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertHod', async function (req, res) {
   const hod = req.body.hod;
   const result = await hodService.insertHod(hod);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertPlacement', async function (req, res) {
   const placement = req.body.placement;
   const result = await placementService.insertPlacement(placement);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertJobProfile', async function (req, res) {
   const jobprofile = req.body.jobprofile;
   const result = await jobprofileService.insertJobProfile(jobprofile);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/insertMarksheet', async function (req, res) {
   const marksheet = req.body.marksheet;
   const result = await marksheetService.insertMarksheet(marksheet);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/applyJobs', async function (req, res) {
   const applyjob = req.body.applyjob;
   const result = await studentService.applyJob(applyjob);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/approveJobs', async function (req, res) {
   const approveJob = req.body.approveJob;
   const result = await jobprofileService.approveJob(approveJob);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});
//* ###################################-----DELETE API-----###################################
app.delete('/deleteStudent/:id', async function (req, res) {
   const student_id = req.params['id'];
   if (student_id) {
      const result = await studentService.deleteStudent(student_id);
      if (result === 1) {
         const resp = {
            'status': 'success'
         }
         res.statusCode = 200;
         res.end(JSON.stringify(resp));
      }
      else {
         const resp = {
            'status': 'error'
         }
         res.statusCode = 500;
         res.end(JSON.stringify(resp));
      }
   }
});

app.delete('/deleteDepartment/:id', async function (req, res) {
   const department_id = req.params['id'];
   if (department_id) {
      const result = await departmentService.deleteDepartment(department_id);
      if (result === 1) {
         const resp = {
            'status': 'success'
         }
         res.statusCode = 200;
         res.end(JSON.stringify(resp));
      }
      else {
         const resp = {
            'status': 'error'
         }
         res.statusCode = 500;
         res.end(JSON.stringify(resp));
      }
   }
});

app.delete('/deleteJobProfile/:id', async function (req, res) {
   const job_id = req.params['id'];
   if (job_id) {
      const result = await jobprofileService.deleteJobProfile(job_id);
      if (result === 1) {
         const resp = {
            'status': 'success'
         }
         res.statusCode = 200;
         res.end(JSON.stringify(resp));
      }
      else {
         const resp = {
            'status': 'error'
         }
         res.statusCode = 500;
         res.end(JSON.stringify(resp));
      }
   }
});

app.delete('/deletePlacement/:id', async function (req, res) {
   const placementId = req.params['id'];
   if (placementId) {
      const result = await placementService.deletePlacement(placementId);
      if (result === 1) {
         const resp = {
            'status': 'success'
         }
         res.statusCode = 200;
         res.end(JSON.stringify(resp));
      }
      else {
         const resp = {
            'status': 'error'
         }
         res.statusCode = 500;
         res.end(JSON.stringify(resp));
      }
   }
});

app.delete('/deleteHod/:id', async function (req, res) {
   const hodId = req.params['id'];
   if (hodId) {
      const result = await hodService.deleteHod(hodId);
      if (result === 1) {
         const resp = {
            'status': 'success'
         }
         res.statusCode = 200;
         res.end(JSON.stringify(resp));
      }
      else {
         const resp = {
            'status': 'error'
         }
         res.statusCode = 500;
         res.end(JSON.stringify(resp));
      }
   }
});

//* ###################################-----UPDATE API-----###################################
app.post('/updateStudent', async function (req, res) {
   const students = req.body.students;
   const result = await studentService.updateStudent(students);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/updateHod', async function (req, res) {
   const hod = req.body.hod;
   const result = await hodService.updateHod(hod);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/updatePlacement', async function (req, res) {
   const placement = req.body.placement;
   const result = await placementService.updatePlacement(placement);
   if (result && result !== null) {
      res.statusCode = 200;
      res.end(JSON.stringify(result));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});

app.post('/updateDepartment', async function (req, res) {
   const departments = req.body.departments;
   const result = await departmentService.updateDepartment(departments);
   if (result == 'S') {
      const resp = {
         'status': 'success'
      }
      res.statusCode = 200;
      res.end(JSON.stringify(resp));
   }
   else {
      const resp = {
         'status': 'error'
      }
      res.statusCode = 500;
      res.end(JSON.stringify(resp));
   }
});


var server = app.listen(8082, function () {
   var host = server.address().addresss
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
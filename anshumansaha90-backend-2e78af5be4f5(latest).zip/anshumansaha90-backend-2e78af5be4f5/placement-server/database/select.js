let con = require('./mysql-connection');

async function selectStudentTable() {
    let query = 'select * from student_vw';
    let array = new Array();
    try {
        const result = await (await con.promise().query(query)).at(0);
        result.forEach(element => {
            let obj = {
                'studentId': element.stu_id,
                'studentName': element.stu_nm,
                'departmentName': element.dept_nm,
                'departmantCode': element.dept_cd,
                'departmentId': element.dept_id,
                'semister1': element.S1,
                'semister2': element.S2,
                'semister3': element.S3,
                'semister4': element.S4,
                'semister5': element.S5,
                'semister6': element.S6,
                'semister7': element.S7,
                'semister8': element.S8,
                'average': element.avg,
                'status': element.sts
            };
            array.push(obj);
        });
        console.log("{result size}" + array.length);
        return array;
    } catch (error) {
        console.error(error)
        process.exit(1)
    }
}

async function fetchStudentByHodId(hodId) {
    let query = 'select * from student_vw where hod_id = ?';
    let value = [hodId];
    let array = new Array();
    const result = await (await con.promise().query(query, value)).at(0);
    result.forEach(element => {
        let obj = {
            'studentId': element.stu_id,
            'studentName': element.stu_nm,
            'departmentName': element.dept_nm,
            'departmantCode': element.dept_cd,
            'departmentId': element.dept_id,
            'semister1': element.S1,
            'semister2': element.S2,
            'semister3': element.S3,
            'semister4': element.S4,
            'semister5': element.S5,
            'semister6': element.S6,
            'semister7': element.S7,
            'semister8': element.S8,
            'average': element.avg,
            'status': element.sts
        };
        array.push(obj);
    });
    return array;
}

async function selectJobprofileTable() {
    let query = 'select * from job_vw';
    let array = new Array();
    const result = await (await con.promise().query(query)).at(0);
    result.forEach(async (element) => {
        let obj = {
            'jobId': element.job_id,
            'companyName': element.comp_nm,
            'jobDate': element.job_dt,
            'departmentName': element.dept_nm,
            'departmantCode': element.dept_cd,
            'semister1': element.S1,
            'semister2': element.S2,
            'semister3': element.S3,
            'semister4': element.S4,
            'semister5': element.S5,
            'semister6': element.S6,
            'semister7': element.S7,
            'semister8': element.S8,
            'average': element.avg,
            'applicableDetails': await setApplicableDetails(element.app_dtl)
        };
        array.push(obj);
    });
    return array;
}


async function fetchJobProfileById(jobId) {
    let query = 'select * from job_vw where job_id = ?';
    const values = [jobId];
    const result = await (await con.promise().query(query, values)).at(0)[0];
    if (result) {
        let response = {
            'jobId': result.job_id,
            'companyName': result.comp_nm,
            'jobDate': result.job_dt,
            'departmentName': result.dept_nm,
            'departmantCode': result.dept_cd,
            'semister1': result.S1,
            'semister2': result.S2,
            'semister3': result.S3,
            'semister4': result.S4,
            'semister5': result.S5,
            'semister6': result.S6,
            'semister7': result.S7,
            'semister8': result.S8,
            'average': result.avg,
            'applicableDetails': await setApplicableDetails(result.app_dtl)
        };
        return response;
    } else {
        return null;
    }
}

async function fetchJobProfileByDepartmentId(departmentId) {
    let query = 'select * from job_vw where dept_id = ?';
    let array = new Array();
    const values = [departmentId];
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(async (element) => {
        let obj = {
            'jobId': element.job_id,
            'companyName': element.comp_nm,
            'jobDate': element.job_dt,
            'departmentName': element.dept_nm,
            'departmantCode': element.dept_cd,
            'semister1': element.S1,
            'semister2': element.S2,
            'semister3': element.S3,
            'semister4': element.S4,
            'semister5': element.S5,
            'semister6': element.S6,
            'semister7': element.S7,
            'semister8': element.S8,
            'average': element.avg,
            'applicableDetails': await setApplicableDetails(element.app_dtl)
        };
        array.push(obj);
    });
    return array;
}

async function selectDepartmentTable() {
    let query = 'select * from department_vw where sts_cd =? order by dept_nm asc';
    let array = new Array();
    let values = ['A'];
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(element => {
        let obj = {
            'departmentId': element.dept_id,
            'departmentName': element.dept_nm,
            'departmentCode': element.dept_cd,
            'departmentStatus': element.sts,
            'hodName': element.hod_nm,
            'hodContactNumber': element.cntct_no,
            'sts': element.sts
        };
        array.push(obj);
    });
    return array;
}

async function selectCriteriaTable() {
    let query = 'select * from criteria_vw';
    let array = new Array();
    const result = await (await con.promise().query(query)).at(0);
    result.forEach(element => {
        let obj = {
            'criteriaId': element.crit_id,
            'semister1': element.S1,
            'semister2': element.S2,
            'semister3': element.S3,
            'semister4': element.S4,
            'semister5': element.S5,
            'semister6': element.S6,
            'semister7': element.S7,
            'semister8': element.S8,
            'average': element.avg
        };
        array.push(obj);
    });
    return array;
}

async function selectMarksheetTable() {
    let query = 'select * from marksheet_vw';
    let array = new Array();
    const result = await (await con.promise().query(query)).at(0);
    result.forEach(element => {
        let obj = {
            'marksheetId': element.mrksht_id,
            'semister1': element.S1,
            'semister2': element.S2,
            'semister3': element.S3,
            'semister4': element.S4,
            'semister5': element.S5,
            'semister6': element.S6,
            'semister7': element.S7,
            'semister8': element.S8,
            'average': element.avg
        };
        array.push(obj);
    });
    return array;
}

async function selectHodTable() {
    let query = 'select * from hod_vw where sts_cd =?';
    let array = new Array();
    let values = ['A'];
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(element => {
        let obj = {
            'hodId': element.hod_id,
            'hodName': element.hod_nm,
            'hodContactNumber': element.cntct_no,
            'departmentName': element.dept_nm,
            'departmentId': element.dept_id,
            'status': element.sts
        };
        array.push(obj);
    });
    return array;
}

async function selectPlacementTable() {
    let query = 'select * from placement_vw where sts_cd =?';
    let array = new Array();
    let values = ['A'];
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(element => {
        let obj = {
            'placementId': element.plcmt_id,
            'placementName': element.plcmt_nm,
            'contactNumber': element.cntct_no,
            'status': element.sts
        };
        array.push(obj);
    });
    return array;
}

async function selectLoginTable(user_id, password, utype) {
    let query = 'select * from login_vw where login_user_id = ? and pwd = ? and utype = ?';
    const values = [user_id, password, utype];
    const result = await (await con.promise().query(query, values)).at(0)[0];
    if (result) {
        let response = {
            'loginId': result.login_id,
            'loginUserId': result.login_user_id,
            'utype': result.utype,
            'userId': result.user_id
        };
        return response;
    }
    else {
        return null;
    }
}

async function fetchStudentById(studentId, loginUserId) {
    let query = 'select * from student_vw where stu_id = ? and login_user_id = ?';
    const values = [studentId, loginUserId];
    const result = await (await con.promise().query(query, values)).at(0)[0];
    let obj = {
        'studentId': result.stu_id,
        'studentName': result.stu_nm,
        'departmentName': result.dept_nm,
        'departmantCode': result.dept_cd,
        'departmentId': result.dept_id,
        'marksheetId': result.mrksht_id,
        'semister1': result.S1,
        'semister2': result.S2,
        'semister3': result.S3,
        'semister4': result.S4,
        'semister5': result.S5,
        'semister6': result.S6,
        'semister7': result.S7,
        'semister8': result.S8,
        'average': result.avg,
        'status': result.sts
    };
    return obj;
}

async function fetchStudentByUserId(studentId) {
    let query = 'select * from student_vw where stu_id = ?';
    const values = [studentId];
    const result = await (await con.promise().query(query, values)).at(0)[0];
    let obj = {
        'studentId': result.stu_id,
        'studentName': result.stu_nm,
        'departmentName': result.dept_nm,
        'departmantCode': result.dept_cd,
        'departmentId': result.dept_id,
        'semister1': result.S1,
        'semister2': result.S2,
        'semister3': result.S3,
        'semister4': result.S4,
        'semister5': result.S5,
        'semister6': result.S6,
        'semister7': result.S7,
        'semister8': result.S8,
        'average': result.avg,
        'status': result.sts
    };
    return obj;
}

async function fetchHodDetailsByHodId(hodId) {
    let query = 'select * from hod_vw where hod_id = ?';
    const values = [hodId];
    const element = await (await con.promise().query(query, values)).at(0)[0];
    let obj = {
        'hodId': element.hod_id,
        'hodName': element.hod_nm,
        'hodContactNumber': element.cntct_no,
        'departmentName': element.dept_nm,
        'departmentId': element.dept_id,
        'status': element.sts
    };
    return obj;
}

async function fetchApplicableJobs(studentId, departmentId, marksheetId) {
    let query = 'select * from applicable_vw where dept_id = ? and mrksht_id = ?';
    const values = [departmentId, marksheetId];
    let array = new Array();
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(element => {
        let obj = {
            'jobId': element.job_id,
            'companyName': element.comp_nm,
            'lastDate': element.job_dt,
            'isApplied': setIsApplicable(element.app_dtl, studentId),
            'isApproved': setIsApproved(element.app_dtl, studentId)
        };
        array.push(obj);
    });
    return array;
}

async function fetchNonApplicableJobs(studentId, loginUserId) {
    let query = 'select * from non_applicable_vw';
    const values = [studentId, loginUserId];
    let array = new Array();
    const result = await (await con.promise().query(query, values)).at(0);
    result.forEach(element => {
        let obj = {
            'jobId': element.job_id,
            'companyName': element.comp_nm,
            'lastDate': element.job_dt
        };
        array.push(obj);
    });
    return array;
}

function setIsApplicable(app_dtl, stu_id) {
    const objString = JSON.stringify(app_dtl);
    const obj = JSON.parse(objString);
    if (obj) {
        const objectFiltered = obj.filter(data => data.studentId === stu_id);
        if (objectFiltered && objectFiltered.length > 0) {
            return objectFiltered[0].isApplied;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

function setIsApproved(app_dtl, stu_id) {
    const objString = JSON.stringify(app_dtl);
    const obj = JSON.parse(objString);
    if (obj) {
        const objectFiltered = obj.filter(data => data.studentId === stu_id);
        if (objectFiltered && objectFiltered.length > 0) {
            return objectFiltered[0].isApproved;
        }
        else {
            return false;
        }
    }
    else {
        return false;
    }
}

async function setApplicableDetails(app_dtl) {
    const objString = JSON.stringify(app_dtl);
    const obj = JSON.parse(objString);
    let array = new Array();
    if (obj) {
        obj.forEach((data) => {
            const obj = {
                'studentId': data.studentId,
                'studentName': data.studentName,
                'isApplied': data.isApplied,
                'isApproved': data.isApproved
            }
            array.push(obj);
        })
    }
    return array;
}

module.exports = {
    selectStudentTable,
    selectJobprofileTable,
    selectDepartmentTable,
    selectCriteriaTable,
    selectMarksheetTable,
    selectHodTable,
    selectPlacementTable,
    selectLoginTable,
    fetchStudentById,
    fetchStudentByUserId,
    fetchApplicableJobs,
    fetchNonApplicableJobs,
    fetchJobProfileById,
    fetchStudentByHodId,
    fetchHodDetailsByHodId,
    fetchJobProfileByDepartmentId
}
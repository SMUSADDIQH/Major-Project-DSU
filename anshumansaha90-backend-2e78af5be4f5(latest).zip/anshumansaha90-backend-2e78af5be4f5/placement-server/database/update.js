let con = require('./mysql-connection');


async function updateStudentTable(studentEntity) {
    let query = 'call sp_students_update(?,?,?,@p_nw_stu_id,@p_pwd); select @p_nw_stu_id, @p_pwd';
    let values = [studentEntity.studentId,studentEntity.studentName, studentEntity.departmentId];
    const result = await con.promise().query(query, values);
    if (result) {
      const resultsetHeaderArray = result[0];
      if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
        const response = resultsetHeaderArray[1];
        const obj = {
          'studentId': response[0]['@p_nw_stu_id'],
          'pwd': response[0]['@p_pwd']
        }
        console.log("Number of records inserted: " + result[0].affectedRows);
        return obj;
      }
    }
    return null;
  }

  async function updateHodTable(hodEntity) {
    let query = 'call sp_hod_update(?,?,?,?,@p_nw_hod_id,@p_pwd); select @p_nw_hod_id, @p_pwd';
    let values = [hodEntity.hodId,hodEntity.hodName, hodEntity.departmentId, hodEntity.contactNumber];
    const result = await con.promise().query(query, values);
    if (result) {
      const resultsetHeaderArray = result[0];
      if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
        const response = resultsetHeaderArray[1];
        const obj = {
          'hodId': response[0]['@p_nw_hod_id'],
          'pwd': response[0]['@p_pwd']
        }
        console.log("Number of records inserted: " + result[0].affectedRows);
        return obj;
      }
    }
    return null;
  }

  async function updatePlacementTable(placementEntity) {
    let query = 'call sp_placement_update(?,?,?,@p_nw_placement_id,@p_pwd); select @p_nw_placement_id, @p_pwd';
    let values = [placementEntity.placementId,placementEntity.placementName, placementEntity.contactNumber];
    const result = await con.promise().query(query, values);
    if (result) {
      const resultsetHeaderArray = result[0];
      if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
        const response = resultsetHeaderArray[1];
        const obj = {
          'placementId': response[0]['@p_nw_placement_id'],
          'pwd': response[0]['@p_pwd']
        }
        console.log("Number of records inserted: " + result[0].affectedRows);
        return obj;
      }
    }
    return null;
  }

  async function updateDepartmentTable(departmentEntity) {
    const query = 'update department_tbl set dept_nm = ?, dept_cd = ? where dept_id = ?';
    const values = [departmentEntity.departmentName, departmentEntity.departmentCode, departmentEntity.departmentId];
    const result = await con.promise().query(query, values);
    if (result && result[0].affectedRows) {
      console.log("Number of records updated: " + result[0].affectedRows);
      return 1;
  }
  return 0;
  }

  async function updateJobProfileTable(applicableDetails, jobId) {
    const query = 'update jobprofile_tbl set app_dtl = ? where job_id = ?';
    const values = [applicableDetails, jobId];
    const result =  await con.promise().query(query, values);
    if (result && result[0].affectedRows) {
      console.log("Number of records updated: " + result[0].affectedRows);
      return 1;
  }
  return 0;
  }


  module.exports = {
    updateStudentTable,
    updateHodTable,
    updatePlacementTable,
    updateDepartmentTable,
    updateJobProfileTable
  }
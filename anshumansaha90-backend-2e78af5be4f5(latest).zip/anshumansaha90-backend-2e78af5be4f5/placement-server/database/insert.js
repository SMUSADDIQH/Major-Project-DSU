let con = require('./mysql-connection');

async function insertStudentTable(studentEntity) {
  let query = 'call sp_students_add(?,?,@p_stu_id,@p_pwd); select @p_stu_id, @p_pwd';
  let values = [studentEntity.studentName, studentEntity.departmentId];
  const result = await con.promise().query(query, values);
  if (result) {
    const resultsetHeaderArray = result[0];
    if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
      const response = resultsetHeaderArray[1];
      const obj = {
        'studentId': response[0]['@p_stu_id'],
        'pwd': response[0]['@p_pwd']
      }
      console.log("Number of records inserted: " + result[0].affectedRows);
      return obj;
    }
  }
  return null;
}

async function insertPlacementTable(placementEntity) {
  let query = 'call sp_placement_add(?,?,@p_placement_id,@p_pwd); select @p_placement_id, @p_pwd';
  let values = [placementEntity.placementName, placementEntity.contactNumber];
  const result = await con.promise().query(query, values);
  if (result) {
    const resultsetHeaderArray = result[0];
    if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
      const response = resultsetHeaderArray[1];
      const obj = {
        'placementId': response[0]['@p_placement_id'],
        'pwd': response[0]['@p_pwd']
      }
      console.log("Number of records inserted: " + result[0].affectedRows);
      return obj;
    }
  }
  return null;
}

async function insertDepartmentTable(departmentEntity) {
  let query = 'insert into department_tbl(dept_nm,dept_cd) values (?)';
  let values = [departmentEntity.departmentName, departmentEntity.departmentCode];
  const result = await con.promise().query(query, [values]);
  if (result && result[0].affectedRows) {
    console.log("Number of records inserted: " + result[0].affectedRows);
    return 1;
  }
  return 0;
}

async function insertCriteriaTable(criteriaEntity) {
  let query = 'insert into criteria_tbl(s1,s2,s3,s4,s5,s6,s7,s8,avg) values (?)';
  let values = [criteriaEntity.semister_1, criteriaEntity.semister_2, criteriaEntity.semister_3, criteriaEntity.semister_4, criteriaEntity.semister_5, criteriaEntity.semister_6, criteriaEntity.semister_7, criteriaEntity.semister_8, criteriaEntity.average];
  const result = await con.promise().query(query, [values]);
  if (result && result[0].affectedRows) {
    console.log("Number of records inserted: " + result[0].affectedRows);
    return 1;
  }
  return 0;
}

async function insertHodTable(hodEntity) {
  let query = 'call sp_hod_add(?,?,?,@p_hod_id,@p_pwd); select @p_hod_id, @p_pwd';
  let values = [hodEntity.hodName, hodEntity.departmentId, hodEntity.contactNumber];
  const result = await con.promise().query(query, values);
  if (result) {
    const resultsetHeaderArray = result[0];
    if (resultsetHeaderArray[0].affectedRows && resultsetHeaderArray[1]) {
      const response = resultsetHeaderArray[1];
      const obj = {
        'hodId': response[0]['@p_hod_id'],
        'pwd': response[0]['@p_pwd']
      }
      console.log("Number of records inserted: " + result[0].affectedRows);
      return obj;
    }
  }
  return null;
}

async function insertJobProfileTable(jobprofileEntity) {
  let query = 'call sp_job_add(?)';
  let values = [jobprofileEntity];
  const result = await con.promise().query(query, values);
  if (result && result[0]) {
    return 1;
  }
  return 0;
}

async function insertMarksheetTable(marksheetEntity) {
  let query = 'call sp_marksheet_add(?)';
  let values = [marksheetEntity];
  const result = await con.promise().query(query, values);
  if (result && result[0]) {
    return 1;
  }
  return 0;
}

async function insertLoginTable(loginEnity) {
  const query = 'insert into login_tbl(user_id, pwd, utype) values (?)';
  const values = [loginEnity.user_id, loginEnity.password, loginEnity.utype];
  const result = await con.promise().query(query, [values]);
  if (result && result[0].affectedRows) {
    console.log("Number of records inserted: " + result[0].affectedRows);
    return 1;
  }
  return 0;
}

async function applyjob(jobDetailObject, jobId) {
  let query = 'call sp_job_apply(?,?)';
  let values = [jobDetailObject, jobId];
  const result = await con.promise().query(query, values);
  if (result && result[0]) {
    return 1;
  }
  return 0;
}

module.exports = {
  insertStudentTable,
  insertDepartmentTable,
  insertCriteriaTable,
  insertHodTable,
  insertJobProfileTable,
  insertMarksheetTable,
  insertPlacementTable,
  insertLoginTable,
  applyjob
}
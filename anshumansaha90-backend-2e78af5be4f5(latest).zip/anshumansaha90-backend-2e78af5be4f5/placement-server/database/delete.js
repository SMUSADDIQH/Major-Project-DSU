let con = require('./mysql-connection');

async function deleteStudentTable(student_id) {
    const query = 'call sp_students_delete(?)';
    const values = [student_id];
    const result = await con.promise().query(query, values);
    if (result) {
        const resultsetHeaderArray = result[0];
        if (resultsetHeaderArray.affectedRows && resultsetHeaderArray) {
            return 1;
        }
    }
    return 0;
}

async function deleteDepartmentTable(department_id) {
    const query = 'delete from department_tbl where dept_id = ?';
    const values = [department_id];
    const result = await con.promise().query(query, values);
    if (result && result[0].affectedRows) {
        console.log("Number of records deleted: " + result[0].affectedRows);
        return 1;
    }
    return 0;
}

async function deletePlacementTable(placementId) {
    const query = 'call sp_placement_delete(?)';
    const values = [placementId];
    const result = await con.promise().query(query, values);
    if (result) {
        const resultsetHeaderArray = result[0];
        if (resultsetHeaderArray.affectedRows && resultsetHeaderArray) {
            return 1;
        }
    }
    return 0;
}

async function deleteHodTable(hodId) {
    const query = 'call sp_hod_delete(?)';
    const values = [hodId];
    const result = await con.promise().query(query, values);
    if (result) {
        const resultsetHeaderArray = result[0];
        if (resultsetHeaderArray.affectedRows && resultsetHeaderArray) {
            return 1;
        }
    }
    return 0;
}

async function deleteJobProfileTable(job_id) {
    const query = 'delete from jobprofile_tbl where job_id = ?';
    const values = [job_id];
    const result = await con.promise().query(query, values);
    if (result && result[0].affectedRows) {
        console.log("Number of records deleted: " + result[0].affectedRows);
        return 1;
    }
    return 0;
}


module.exports = {
    deleteStudentTable,
    deleteDepartmentTable,
    deletePlacementTable,
    deleteHodTable,
    deleteJobProfileTable
}